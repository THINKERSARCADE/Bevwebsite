const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from 'react';

import { useToast } from '@/components/ui/use-toast';

export default function ReturnRequestForm({ order, phone = '' }) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [type, setType] = useState('return');
  const [reason, setReason] = useState('');
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  if (!order) return null;

  const submit = async (event) => {
    event.preventDefault();
    if (reason.trim().length < 5) {
      setError('Tell us briefly why you would like to return or exchange.');
      return;
    }
    setSaving(true);
    try {
      await db.entities.ReturnRequest.create({
        order_number: order.order_number,
        name: '',
        phone,
        type,
        reason: reason.trim(),
        status: 'new',
      });
      setSent(true);
      setReason('');
      toast({ title: 'Request sent', description: 'Our team will be in touch shortly.' });
    } catch {
      setError('Could not send the request. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mt-10 border-t border-border/70 pt-6">
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground underline-offset-8 hover:text-foreground hover:underline"
      >
        {open ? 'Close' : 'Request a return or exchange'}
      </button>

      {open && (
        <div className="mt-5 border border-border/70 p-5">
          {sent ? (
            <p className="text-sm text-muted-foreground">
              Thank you — your request has been logged against order {order.order_number}.
            </p>
          ) : (
            <form onSubmit={submit} className="space-y-4">
              <div className="flex gap-2">
                {['return', 'exchange'].map((option) => (
                  <button
                    key={option}
                    type="button"
                    onClick={() => setType(option)}
                    className={`border px-3 py-2 text-[10px] uppercase tracking-[0.18em] capitalize ${
                      type === option ? 'border-foreground bg-foreground text-background' : 'border-border'
                    }`}
                  >
                    {option}
                  </button>
                ))}
              </div>
              <textarea
                value={reason}
                onChange={(event) => {
                  setReason(event.target.value);
                  setError('');
                }}
                rows={3}
                placeholder="Which item, and why?"
                className="field resize-none"
              />
              {error && <p className="text-xs text-destructive">{error}</p>}
              <button type="submit" disabled={saving} className="btn-outline w-full disabled:opacity-60">
                {saving ? 'Sending…' : 'Send request'}
              </button>
            </form>
          )}
        </div>
      )}
    </div>
  );
}