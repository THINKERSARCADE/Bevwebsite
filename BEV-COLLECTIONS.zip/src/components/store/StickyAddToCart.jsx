import { useEffect, useState } from 'react';
import { ShoppingBag } from 'lucide-react';
import { formatKES } from '@/lib/shop';

export default function StickyAddToCart({ product, soldOut, onAdd }) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const gallery = document.getElementById('product-gallery');
    if (!gallery || typeof IntersectionObserver === 'undefined') return undefined;
    const observer = new IntersectionObserver(
      ([entry]) => setVisible(!entry.isIntersecting),
      { threshold: 0 }
    );
    observer.observe(gallery);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      className={`fixed inset-x-0 z-40 border-t border-border/70 bg-background/95 backdrop-blur-md transition-transform duration-300 md:hidden ${
        visible ? 'translate-y-0' : 'translate-y-[130%]'
      }`}
      style={{ bottom: 'calc(3.5rem + env(safe-area-inset-bottom))' }}
      aria-hidden={!visible}
    >
      <div className="flex items-center gap-3 px-4 py-3">
        <div className="min-w-0 flex-1">
          <p className="truncate text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
            {product.name}
          </p>
          <p className="text-sm font-medium tracking-[0.03em]">{formatKES(product.price)}</p>
        </div>
        <button
          type="button"
          onClick={onAdd}
          disabled={soldOut}
          className="btn-primary min-h-[46px] flex-1 justify-center py-3 disabled:opacity-40"
        >
          <ShoppingBag className="h-4 w-4" strokeWidth={1.6} />
          {soldOut ? 'Sold out' : 'Add to Bag'}
        </button>
      </div>
    </div>
  );
}