import { discountPercent } from '@/lib/shop';
import { cn } from '@/lib/utils';

/**
 * Sale flag shown on product cards whenever a piece is priced under its
 * compare-at price, so discounted pieces stand out while browsing.
 */
export default function SaleBadge({ product, className }) {
  const off = discountPercent(product?.price, product?.compare_price);
  if (!off) return null;

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 bg-accent px-2 py-1 text-[9px] font-medium uppercase leading-none tracking-[0.18em] text-accent-foreground shadow-sm',
        className
      )}
    >
      Sale
      <span className="text-[8px] opacity-80">−{off}%</span>
    </span>
  );
}