import { Link } from 'react-router-dom';
import ProductCard from './ProductCard';
import SectionHeader from './SectionHeader';

export default function ProductRail({ eyebrow, title, description, products = [], actionLabel = 'View all', actionTo = '/shop', columns = 4 }) {
  if (!products.length) return null;

  return (
    <section className="shell py-16 md:py-24">
      <SectionHeader
        eyebrow={eyebrow}
        title={title}
        description={description}
        action={
          <Link
            to={actionTo}
            className="text-[10px] uppercase tracking-[0.26em] text-muted-foreground underline-offset-8 hover:text-foreground hover:underline"
          >
            {actionLabel}
          </Link>
        }
      />
      <div
        className={`mt-12 grid gap-x-4 gap-y-10 sm:grid-cols-2 ${
          columns === 3 ? 'lg:grid-cols-3' : 'lg:grid-cols-4'
        }`}
      >
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </section>
  );
}