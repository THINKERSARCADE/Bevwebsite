import { Outlet } from 'react-router-dom';
import Header from './Header';
import Footer from './Footer';
import BottomNav from './BottomNav';
import CartSheet from './CartSheet';
import WhatsAppButton from './WhatsAppButton';
import { useStore } from '@/context/StoreContext';

export default function StoreLayout() {
  const { content } = useStore();

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <a
        href="#store-content"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:bg-foreground focus:px-4 focus:py-2 focus:text-background"
      >
        Skip to content
      </a>
      <Header announcement={content.announcement} />
      <main id="store-content" className="bottom-nav-safe flex-1 md:pb-0">
        <Outlet />
      </main>
      <Footer />
      <WhatsAppButton />
      <BottomNav />
      <CartSheet />
    </div>
  );
}