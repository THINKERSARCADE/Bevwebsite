import { useEffect, useRef, useState } from 'react';
import { ZoomIn } from 'lucide-react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Image } from '@/components/ui/image';
import { cn } from '@/lib/utils';

export default function ProductGallery({ images = [], name }) {
  const list = images.length ? images : [''];
  const [index, setIndex] = useState(0);
  const [zoomOpen, setZoomOpen] = useState(false);
  const scroller = useRef(null);

  const goTo = (next) => {
    const element = scroller.current;
    setIndex(next);
    if (element) element.scrollTo({ left: next * element.clientWidth, behavior: 'smooth' });
  };

  const handleScroll = () => {
    const element = scroller.current;
    if (!element) return;
    const next = Math.round(element.scrollLeft / element.clientWidth);
    if (next !== index) setIndex(next);
  };

  return (
    <div id="product-gallery">
      <div className="md:hidden">
        <div
          ref={scroller}
          onScroll={handleScroll}
          className="no-scrollbar -mx-5 flex snap-x snap-mandatory overflow-x-auto"
        >
          {list.map((image, position) => (
            <button
              key={`${image}-${position}`}
              type="button"
              onClick={() => setZoomOpen(true)}
              aria-label={`View ${name} image ${position + 1} full screen`}
              className="w-full shrink-0 snap-center bg-secondary"
            >
              <Image
                src={image}
                alt={`${name} — view ${position + 1}`}
                className="aspect-[4/5] w-full"
                fittingType="fill"
              />
            </button>
          ))}
        </div>

        {list.length > 1 && (
          <div className="mt-2 flex items-center justify-center">
            {list.map((image, position) => (
              <button
                key={`dot-${position}`}
                type="button"
                onClick={() => goTo(position)}
                aria-label={`Go to image ${position + 1}`}
                aria-current={index === position}
                className="grid h-10 w-7 place-items-center"
              >
                <span
                  className={cn(
                    'h-1.5 rounded-full transition-all duration-300',
                    index === position ? 'w-5 bg-foreground' : 'w-1.5 bg-border'
                  )}
                />
              </button>
            ))}
          </div>
        )}

        <p className="flex items-center justify-center gap-1.5 pb-1 text-[9px] uppercase tracking-[0.18em] text-muted-foreground">
          <ZoomIn className="h-3 w-3" strokeWidth={1.6} /> Tap image to zoom
        </p>
      </div>

      <div className="hidden md:block">
        <div className="overflow-hidden bg-secondary">
          <Image
            src={list[index]}
            alt={name}
            className="aspect-[4/5] w-full"
            fittingType="fill"
          />
        </div>
        {list.length > 1 && (
          <div className="mt-3 grid grid-cols-5 gap-2">
            {list.map((image, position) => (
              <button
                key={`thumb-${position}`}
                type="button"
                onClick={() => setIndex(position)}
                className={cn(
                  'overflow-hidden border',
                  index === position ? 'border-foreground' : 'border-transparent'
                )}
              >
                <Image
                  src={image}
                  alt={`${name} view ${position + 1}`}
                  className="aspect-square w-full"
                  fittingType="fill"
                />
              </button>
            ))}
          </div>
        )}
      </div>

      <Dialog open={zoomOpen} onOpenChange={setZoomOpen}>
        <DialogContent className="max-w-3xl border-border bg-background p-0">
          <div
            className="max-h-[85vh] overflow-auto overscroll-contain"
            style={{ touchAction: 'pinch-zoom' }}
          >
            <Image src={list[index]} alt={name} className="w-full" fittingType="fit" />
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}