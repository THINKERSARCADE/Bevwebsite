import { Link } from 'react-router-dom';
import { Image } from '@/components/ui/image';
import { useStore } from '@/context/StoreContext';

export default function PromoBanner() {
  const { content } = useStore();

  return (
    <section className="relative mt-8 overflow-hidden">
      <Image
        src={content.promo_image}
        alt="Bev Collections seasonal campaign"
        className="h-[70vh] w-full md:h-[78vh]"
        fittingType="fill"
        focalPointY={0.45}
      />
      <div className="absolute inset-0 bg-foreground/35" />
      <div className="absolute inset-0 flex items-center">
        <div className="shell max-w-xl text-background">
          <p className="text-[10px] uppercase tracking-[0.34em] text-background/80">
            Seasonal edit
          </p>
          <h2 className="mt-5 whitespace-pre-line font-display text-[clamp(2.2rem,4.6vw,3.9rem)] font-light leading-[1.02] tracking-[-0.02em]">
            {content.promo_heading}
          </h2>
          <p className="mt-5 max-w-sm text-sm leading-relaxed text-background/85">
            {content.promo_text}
          </p>
          <Link
            to={content.promo_cta_link || '/shop?filter=sale'}
            className="mt-9 inline-flex items-center justify-center bg-background px-9 py-4 text-[10px] uppercase tracking-[0.28em] text-foreground transition-colors duration-300 hover:bg-accent"
          >
            {content.promo_cta_label || 'Shop the Sale'}
          </Link>
        </div>
      </div>
    </section>
  );
}