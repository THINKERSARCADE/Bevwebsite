import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Image } from '@/components/ui/image';
import { useCart } from '@/context/CartContext';
import { formatKES, swatchFor, discountPercent } from '@/lib/shop';
import { cn } from '@/lib/utils';

export default function QuickViewDialog({ product, open, onOpenChange }) {
  const { addItem, openCart } = useCart();
  const [size, setSize] = useState('');
  const [color, setColor] = useState('');
  const [error, setError] = useState('');

  if (!product) return null;
  const sizes = product.sizes || [];
  const colors = product.colors || [];
  const off = discountPercent(product.price, product.compare_price);

  const handleAdd = () => {
    if (sizes.length && !size) return setError('Please select a size.');
    if (colors.length && !color) return setError('Please select a colour.');
    setError('');
    addItem(product, { size, color, qty: 1 });
    onOpenChange(false);
    // Let this dialog finish closing before the bag sheet takes over.
    setTimeout(openCart, 220);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl gap-0 overflow-hidden border-border bg-background p-0">
        <div className="grid md:grid-cols-2">
          <div className="relative aspect-[4/5] bg-secondary">
            <Image src={product.images?.[0]} alt={product.name} className="h-full w-full" fittingType="fill" />
          </div>
          <div className="flex flex-col p-6 md:p-8">
            <p className="eyebrow">{product.category}</p>
            <h3 className="mt-3 font-display text-3xl leading-tight tracking-tight">{product.name}</h3>
            <div className="mt-3 flex items-baseline gap-3">
              <span className="text-base font-medium tracking-wide">{formatKES(product.price)}</span>
              {product.compare_price ? (
                <span className="text-sm text-muted-foreground line-through">
                  {formatKES(product.compare_price)}
                </span>
              ) : null}
              {off > 0 && (
                <span className="text-[10px] uppercase tracking-[0.2em] text-accent">-{off}%</span>
              )}
            </div>
            <p className="mt-4 line-clamp-3 text-sm leading-relaxed text-muted-foreground">
              {product.description}
            </p>

            {sizes.length > 0 && (
              <div className="mt-6">
                <p className="eyebrow">Size</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {sizes.map((option) => (
                    <button
                      key={option}
                      type="button"
                      onClick={() => setSize(option)}
                      className={cn(
                        'min-w-11 border px-3 py-2 text-[11px] tracking-[0.14em] transition-colors',
                        size === option
                          ? 'border-foreground bg-foreground text-background'
                          : 'border-border hover:border-foreground'
                      )}
                    >
                      {option}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {colors.length > 0 && (
              <div className="mt-5">
                <p className="eyebrow">Colour</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {colors.map((option) => (
                    <button
                      key={option}
                      type="button"
                      onClick={() => setColor(option)}
                      className={cn(
                        'flex items-center gap-2 border px-3 py-2 text-[11px] tracking-[0.1em] transition-colors',
                        color === option ? 'border-foreground' : 'border-border hover:border-foreground/50'
                      )}
                    >
                      <span
                        className="h-3 w-3 rounded-full border border-border"
                        style={{ backgroundColor: swatchFor(option) }}
                      />
                      {option}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {error && <p className="mt-4 text-xs text-destructive">{error}</p>}

            <button type="button" onClick={handleAdd} className="btn-primary mt-6 w-full">
              Add to Bag
            </button>
            <Link
              to={`/product/${product.slug}`}
              onClick={() => onOpenChange(false)}
              className="mt-3 text-center text-[10px] uppercase tracking-[0.24em] text-muted-foreground underline-offset-4 hover:text-foreground hover:underline"
            >
              View full details
            </Link>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}