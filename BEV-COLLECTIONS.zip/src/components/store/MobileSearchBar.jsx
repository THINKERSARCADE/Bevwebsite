import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, SlidersHorizontal } from 'lucide-react';

export default function MobileSearchBar() {
  const [term, setTerm] = useState('');
  const navigate = useNavigate();

  const submit = (event) => {
    event.preventDefault();
    const query = term.trim();
    navigate(query ? `/shop?q=${encodeURIComponent(query)}` : '/shop');
  };

  return (
    <div className="shell md:hidden">
      <form
        onSubmit={submit}
        className="flex items-center gap-3 rounded-md border border-border/80 bg-card px-4 py-3"
      >
        <Search className="h-4 w-4 shrink-0 text-muted-foreground" strokeWidth={1.5} />
        <input
          value={term}
          onChange={(event) => setTerm(event.target.value)}
          placeholder="Search shoes, bags, clothing…"
          className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground/70"
          aria-label="Search products"
        />
        <button
          type="submit"
          aria-label="Browse with filters"
          className="grid h-7 w-7 shrink-0 place-items-center rounded border border-border/80 text-muted-foreground"
        >
          <SlidersHorizontal className="h-3.5 w-3.5" strokeWidth={1.6} />
        </button>
      </form>
    </div>
  );
}