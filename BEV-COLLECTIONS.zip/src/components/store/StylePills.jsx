import { Link } from 'react-router-dom';

const PILLS = [
  { label: 'All', to: '/shop' },
  { label: 'Newest', to: '/shop?filter=new' },
  { label: 'Shoes', to: '/shop/shoes' },
  { label: 'Bags', to: '/shop/handbags' },
  { label: 'Clothing', to: '/shop/clothing' },
  { label: 'Sale', to: '/shop?filter=sale' },
];

export default function StylePills() {
  return (
    <div className="no-scrollbar -mx-5 overflow-x-auto px-5 md:mx-0 md:px-0">
      <div className="flex w-max items-center gap-2 md:w-auto md:flex-wrap">
        {PILLS.map((pill, index) => (
          <Link
            key={pill.label}
            to={pill.to}
            className={
              index === 0
                ? 'rounded-full bg-foreground px-4 py-2 text-[10px] uppercase tracking-[0.18em] text-background'
                : 'rounded-full border border-border/80 px-4 py-2 text-[10px] uppercase tracking-[0.18em] text-foreground/75 transition-colors hover:border-foreground hover:text-foreground'
            }
          >
            {pill.label}
          </Link>
        ))}
      </div>
    </div>
  );
}