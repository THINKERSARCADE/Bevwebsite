import { MessageCircle } from 'lucide-react';
import { useStore } from '@/context/StoreContext';

export default function WhatsAppButton({
  message = 'Hello Bev Collections, I would like to enquire about a piece.',
}) {
  const { content } = useStore();
  const digits = String(content.whatsapp || '').replace(/\D/g, '');
  if (!digits) return null;

  return (
    <a
      href={`https://wa.me/${digits}?text=${encodeURIComponent(message)}`}
      target="_blank"
      rel="noreferrer"
      aria-label="Chat with us on WhatsApp"
      className="fixed bottom-[76px] right-4 z-30 flex items-center gap-2 rounded-full bg-foreground px-4 py-3 text-background shadow-lg shadow-foreground/20 transition-transform duration-300 hover:scale-105 md:bottom-8 md:right-8"
    >
      <MessageCircle className="h-4 w-4" strokeWidth={1.6} />
      <span className="hidden text-[10px] uppercase tracking-[0.22em] sm:block">WhatsApp</span>
    </a>
  );
}