export default function SectionHeader({ eyebrow, title, description, action }) {
  return (
    <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
      <div>
        {eyebrow && <p className="eyebrow">{eyebrow}</p>}
        <h2 className="mt-4 font-display text-4xl leading-tight tracking-[-0.02em] md:text-5xl">
          {title}
        </h2>
        {description && (
          <p className="mt-4 max-w-md text-sm leading-relaxed text-muted-foreground">{description}</p>
        )}
      </div>
      {action}
    </div>
  );
}