const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from 'react';
import { ArrowRight } from 'lucide-react';

export default function Newsletter() {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [status, setStatus] = useState('idle');

  const handleSubmit = async (event) => {
    event.preventDefault();
    const valid = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim());
    if (!valid) {
      setError('Enter a valid email address.');
      return;
    }
    setError('');
    setStatus('saving');
    try {
      await db.entities.Subscriber.create({ email: email.trim().toLowerCase() });
      setStatus('done');
      setEmail('');
    } catch {
      setError('We could not save that just now. Please try again.');
      setStatus('idle');
    }
  };

  return (
    <section className="border-t border-border/70 bg-card">
      <div className="shell grid gap-10 py-20 md:grid-cols-2 md:items-center md:py-24">
        <div>
          <p className="eyebrow">Newsletter</p>
          <h2 className="mt-4 font-display text-4xl tracking-[-0.02em] md:text-5xl">
            BE THE FIRST TO KNOW
          </h2>
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted-foreground">
            Get updates on new arrivals, exclusive offers and the latest fashion trends.
          </p>
        </div>

        <div>
          <form onSubmit={handleSubmit} className="flex items-center gap-3 border-b border-foreground/30 pb-3">
            <input
              type="email"
              value={email}
              onChange={(event) => {
                setEmail(event.target.value);
                setError('');
                setStatus('idle');
              }}
              placeholder="Your email address"
              className="w-full bg-transparent text-sm tracking-wide outline-none placeholder:text-muted-foreground/70"
              aria-label="Email address"
            />
            <button
              type="submit"
              disabled={status === 'saving'}
              className="flex shrink-0 items-center gap-2 text-[10px] uppercase tracking-[0.26em] transition-colors hover:text-accent disabled:opacity-50"
            >
              {status === 'saving' ? 'Adding…' : 'Subscribe'}
              <ArrowRight className="h-3.5 w-3.5" strokeWidth={1.6} />
            </button>
          </form>
          {error && <p className="mt-3 text-xs text-destructive">{error}</p>}
          {status === 'done' && (
            <p className="mt-3 text-xs text-muted-foreground">
              You are on the list. Look out for our next drop.
            </p>
          )}
          <p className="mt-4 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
            New arrivals · Private offers · Styling notes
          </p>
        </div>
      </div>
    </section>
  );
}