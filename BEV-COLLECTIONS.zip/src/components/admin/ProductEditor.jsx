const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState } from 'react';

import ImageUploadField from './ImageUploadField';
import VariationEditor from './VariationEditor';
import { slugify } from '@/lib/shop';

const empty = {
  name: '',
  sku: '',
  slug: '',
  category: 'shoes',
  description: '',
  price: '',
  compare_price: '',
  stock: '',
  sizes: '',
  colors: '',
  images: [''],
  variations: [],
  is_featured: false,
  is_new_arrival: true,
  is_best_seller: false,
  is_active: true,
};

export default function ProductEditor({ product, categories, onClose, onSaved }) {
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (product) {
      setForm({
        ...empty,
        ...product,
        price: String(product.price ?? ''),
        compare_price: String(product.compare_price ?? ''),
        stock: String(product.stock ?? ''),
        sizes: (product.sizes || []).join(', '),
        colors: (product.colors || []).join(', '),
        images: product.images?.length ? product.images : [''],
      });
    } else {
      setForm(empty);
    }
  }, [product]);

  const update = (key, value) => setForm((previous) => ({ ...previous, [key]: value }));

  const save = async (event) => {
    event.preventDefault();
    setSaving(true);
    const payload = {
      name: form.name.trim(),
      sku: form.sku.trim(),
      slug: (form.slug || slugify(form.name)).trim(),
      category: form.category,
      description: form.description,
      price: Number(form.price) || 0,
      compare_price: form.compare_price ? Number(form.compare_price) : null,
      stock: Number(form.stock) || 0,
      sizes: form.sizes.split(',').map((item) => item.trim()).filter(Boolean),
      colors: form.colors.split(',').map((item) => item.trim()).filter(Boolean),
      variations: (form.variations || []).filter((variation) => variation.size || variation.color),
      images: form.images.filter(Boolean),
      is_featured: form.is_featured,
      is_new_arrival: form.is_new_arrival,
      is_best_seller: form.is_best_seller,
      is_active: form.is_active,
      tags: form.tags || [],
    };

    try {
      if (product) await db.entities.Product.update(product.id, payload);
      else await db.entities.Product.create(payload);
      onSaved();
      onClose();
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-foreground/40 p-4">
      <form onSubmit={save} className="my-8 w-full max-w-2xl bg-background p-6 md:p-8">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-2xl tracking-tight">
            {product ? 'Edit product' : 'New product'}
          </h2>
          <button type="button" onClick={onClose} className="text-xs uppercase tracking-[0.2em]">
            Close
          </button>
        </div>

        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          <label className="block sm:col-span-2">
            <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Name</span>
            <input value={form.name} onChange={(e) => update('name', e.target.value)} className="field mt-2" required />
          </label>
          <label className="block">
            <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">SKU</span>
            <input value={form.sku} onChange={(e) => update('sku', e.target.value)} className="field mt-2" />
          </label>
          <label className="block">
            <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Slug</span>
            <input value={form.slug} onChange={(e) => update('slug', e.target.value)} className="field mt-2" placeholder="auto from name" />
          </label>
          <label className="block">
            <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Category</span>
            <select value={form.category} onChange={(e) => update('category', e.target.value)} className="field mt-2">
              {categories.map((category) => (
                <option key={category.slug} value={category.slug}>
                  {category.name}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Stock</span>
            <input value={form.stock} onChange={(e) => update('stock', e.target.value)} className="field mt-2" inputMode="numeric" />
          </label>
          <label className="block">
            <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Price (KSh)</span>
            <input value={form.price} onChange={(e) => update('price', e.target.value)} className="field mt-2" inputMode="numeric" required />
          </label>
          <label className="block">
            <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Compare price (KSh)</span>
            <input value={form.compare_price} onChange={(e) => update('compare_price', e.target.value)} className="field mt-2" inputMode="numeric" />
          </label>
          <label className="block">
            <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Sizes (comma separated)</span>
            <input value={form.sizes} onChange={(e) => update('sizes', e.target.value)} className="field mt-2" placeholder="36, 37, 38" />
          </label>
          <label className="block">
            <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Colours (comma separated)</span>
            <input value={form.colors} onChange={(e) => update('colors', e.target.value)} className="field mt-2" placeholder="Black, Tan" />
          </label>
          <label className="block sm:col-span-2">
            <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Description</span>
            <textarea value={form.description} onChange={(e) => update('description', e.target.value)} rows={3} className="field mt-2 resize-none" />
          </label>
        </div>

        <div className="mt-6 rounded-md border border-border/70 p-4">
          <VariationEditor
            sizes={form.sizes.split(',').map((item) => item.trim()).filter(Boolean)}
            colors={form.colors.split(',').map((item) => item.trim()).filter(Boolean)}
            variations={form.variations || []}
            onChange={(value) => update('variations', value)}
          />
        </div>

        <div className="mt-6 space-y-4">
          <ImageUploadField
            label="Main image"
            value={form.images[0]}
            onChange={(value) => update('images', [value, ...form.images.slice(1)])}
          />
          <ImageUploadField
            label="Second image (optional)"
            value={form.images[1]}
            onChange={(value) => update('images', [form.images[0], value].filter(Boolean))}
          />
        </div>

        <div className="mt-6 flex flex-wrap gap-4">
          {[
            ['is_new_arrival', 'New arrival'],
            ['is_featured', 'Featured'],
            ['is_best_seller', 'Best seller'],
            ['is_active', 'Visible in store'],
          ].map(([key, label]) => (
            <label key={key} className="flex items-center gap-2 text-xs">
              <input
                type="checkbox"
                checked={Boolean(form[key])}
                onChange={(e) => update(key, e.target.checked)}
                className="h-3.5 w-3.5 accent-foreground"
              />
              {label}
            </label>
          ))}
        </div>

        <div className="mt-8 flex gap-3">
          <button type="submit" disabled={saving} className="btn-primary flex-1 disabled:opacity-60">
            {saving ? 'Saving…' : 'Save product'}
          </button>
          <button type="button" onClick={onClose} className="btn-outline">
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
}