const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from 'react';

export default function ImageUploadField({ label, value, onChange }) {
  const [uploading, setUploading] = useState(false);

  const upload = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await db.integrations.Core.UploadPublicFile({ file });
      onChange(file_url);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div>
      <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">{label}</span>
      <div className="mt-2 flex items-center gap-3">
        {value ? (
          <img src={value} alt="" className="h-14 w-14 shrink-0 object-cover" />
        ) : (
          <div className="h-14 w-14 shrink-0 border border-dashed border-border" />
        )}
        <div className="flex-1 space-y-2">
          <input
            value={value || ''}
            onChange={(event) => onChange(event.target.value)}
            placeholder="Image URL"
            className="field"
          />
          <label className="inline-block cursor-pointer text-[10px] uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground">
            {uploading ? 'Uploading…' : 'Upload image'}
            <input type="file" accept="image/*" onChange={upload} className="hidden" />
          </label>
        </div>
      </div>
      <p className="mt-1 text-[10px] text-muted-foreground">Images are stored publicly (anyone with the link can open them).</p>
    </div>
  );
}