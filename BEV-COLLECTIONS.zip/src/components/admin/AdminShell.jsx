const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Bell,
  ExternalLink,
  Inbox,
  LayoutDashboard,
  LogOut,
  Menu,
  Package,
  Search,
  ShoppingCart,
  Store,
  Tag,
  Tags,
  Truck,
  Users,
  X,
} from 'lucide-react';

import { cn } from '@/lib/utils';

const GROUPS = [
  {
    title: 'General',
    items: [
      { id: 'overview', label: 'Dashboard', icon: LayoutDashboard },
      { id: 'products', label: 'Products', icon: Package },
      { id: 'orders', label: 'Orders', icon: ShoppingCart },
      { id: 'customers', label: 'Customers', icon: Users },
    ],
  },
  {
    title: 'Operations',
    items: [
      { id: 'promos', label: 'Delivery & codes', icon: Truck },
      { id: 'catalogue', label: 'Categories', icon: Tags },
      { id: 'storefront', label: 'Storefront', icon: Store },
    ],
  },
  {
    title: 'Account',
    items: [{ id: 'inbox', label: 'Inbox', icon: Inbox }],
  },
];

export default function AdminShell({ active, onNavigate, onSearch, children }) {
  const [open, setOpen] = useState(false);
  const [user, setUser] = useState(null);
  const [term, setTerm] = useState('');

  useEffect(() => {
    db.auth.me().then(setUser).catch(() => {});
  }, []);

  const label = GROUPS.flatMap((group) => group.items).find((item) => item.id === active)?.label;

  const submitSearch = (event) => {
    event.preventDefault();
    onSearch?.(term.trim());
    setOpen(false);
  };

  const nav = (
    <nav className="flex h-full flex-col">
      <div className="flex items-center gap-2.5 px-5 py-5">
        <span className="grid h-8 w-8 place-items-center rounded-md bg-sage text-[11px] font-medium text-sage-foreground">
          B
        </span>
        <div>
          <p className="text-[13px] font-medium leading-none text-background">Bev Collections</p>
          <p className="mt-1 text-[9px] uppercase tracking-[0.2em] text-background/40">Admin</p>
        </div>
      </div>

      <div className="flex-1 space-y-6 overflow-y-auto px-3 py-2">
        {GROUPS.map((group) => (
          <div key={group.title}>
            <p className="px-2 pb-2 text-[9px] uppercase tracking-[0.22em] text-background/35">
              {group.title}
            </p>
            <div className="space-y-1">
              {group.items.map((item) => {
                const Icon = item.icon;
                const isActive = active === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      onNavigate(item.id);
                      setOpen(false);
                    }}
                    className={cn(
                      'flex w-full items-center gap-3 rounded-md px-2.5 py-2.5 text-left text-[13px] transition-colors',
                      isActive
                        ? 'bg-background/10 text-background'
                        : 'text-background/60 hover:bg-background/5 hover:text-background'
                    )}
                  >
                    <Icon className="h-4 w-4 shrink-0" strokeWidth={1.6} />
                    {item.label}
                    {isActive && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-sage" />}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      <div className="space-y-1 border-t border-background/10 px-3 py-3">
        <Link
          to="/"
          className="flex items-center gap-3 rounded-md px-2.5 py-2.5 text-[13px] text-background/60 transition-colors hover:bg-background/5 hover:text-background"
        >
          <ExternalLink className="h-4 w-4" strokeWidth={1.6} /> View store
        </Link>
        <button
          type="button"
          onClick={() => db.auth.logout('/')}
          className="flex w-full items-center gap-3 rounded-md px-2.5 py-2.5 text-left text-[13px] text-background/60 transition-colors hover:bg-background/5 hover:text-background"
        >
          <LogOut className="h-4 w-4" strokeWidth={1.6} /> Sign out
        </button>
      </div>
    </nav>
  );

  return (
    <div className="min-h-screen bg-secondary/40">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-60 bg-foreground lg:block">{nav}</aside>

      <div
        className={cn(
          'fixed inset-0 z-50 lg:hidden',
          open ? 'pointer-events-auto' : 'pointer-events-none'
        )}
      >
        <div
          className={cn(
            'absolute inset-0 bg-foreground/50 transition-opacity',
            open ? 'opacity-100' : 'opacity-0'
          )}
          onClick={() => setOpen(false)}
        />
        <div
          className={cn(
            'absolute inset-y-0 left-0 w-64 bg-foreground transition-transform',
            open ? 'translate-x-0' : '-translate-x-full'
          )}
        >
          <button
            type="button"
            onClick={() => setOpen(false)}
            className="absolute right-3 top-4 text-background/60"
            aria-label="Close menu"
          >
            <X className="h-5 w-5" />
          </button>
          {nav}
        </div>
      </div>

      <div className="lg:pl-60">
        <header className="sticky top-0 z-20 border-b border-border/60 bg-background/90 backdrop-blur">
          <div className="flex items-center gap-3 px-4 py-3 md:px-6">
            <button
              type="button"
              onClick={() => setOpen(true)}
              className="grid h-9 w-9 place-items-center rounded-md border border-border lg:hidden"
              aria-label="Open menu"
            >
              <Menu className="h-4 w-4" strokeWidth={1.6} />
            </button>

            <form
              onSubmit={submitSearch}
              className="hidden items-center gap-2 rounded-md border border-border bg-card px-3 py-2 sm:flex"
            >
              <Search className="h-3.5 w-3.5 text-muted-foreground" strokeWidth={1.6} />
              <input
                value={term}
                onChange={(event) => setTerm(event.target.value)}
                placeholder="Search products"
                className="w-44 bg-transparent text-xs outline-none placeholder:text-muted-foreground/70"
              />
            </form>

            <p className="truncate text-[10px] uppercase tracking-[0.22em] text-muted-foreground lg:hidden">
              {label}
            </p>

            <div className="ml-auto flex items-center gap-2">
              <Link
                to="/"
                className="hidden rounded-md border border-border bg-card px-3 py-2 text-[10px] uppercase tracking-[0.18em] text-muted-foreground hover:text-foreground md:block"
              >
                Storefront
              </Link>
              <span className="grid h-9 w-9 place-items-center rounded-md border border-border bg-card text-muted-foreground">
                <Bell className="h-4 w-4" strokeWidth={1.6} />
              </span>
              <div className="flex items-center gap-2 rounded-md border border-border bg-card py-1.5 pl-1.5 pr-3">
                <span className="grid h-6 w-6 place-items-center rounded-full bg-sage text-[10px] font-medium text-sage-foreground">
                  {(user?.full_name || user?.email || 'B').charAt(0).toUpperCase()}
                </span>
                <span className="hidden max-w-[120px] truncate text-[11px] text-muted-foreground sm:block">
                  {user?.full_name || user?.email || 'Admin'}
                </span>
              </div>
            </div>
          </div>
        </header>

        <main className="px-4 py-6 md:px-6 md:py-8">{children}</main>
      </div>
    </div>
  );
}