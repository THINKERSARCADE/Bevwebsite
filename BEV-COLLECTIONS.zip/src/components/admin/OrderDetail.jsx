const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from 'react';

import { formatKES } from '@/lib/shop';
import { ORDER_STATUSES, PAYMENT_LABELS, statusLabel } from '@/lib/orders';

export default function OrderDetail({ order, onClose, onUpdated }) {
  const [status, setStatus] = useState(order.order_status);
  const [payment, setPayment] = useState(order.payment_status);
  const [receipt, setReceipt] = useState(order.mpesa_receipt || '');
  const [tracking, setTracking] = useState(order.tracking_ref || '');
  const [note, setNote] = useState(order.admin_note || '');
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    const history = Array.isArray(order.status_history) ? order.status_history : [];
    const changed = status !== order.order_status || payment !== order.payment_status;

    await db.entities.Order.update(order.id, {
      order_status: status,
      payment_status: payment,
      mpesa_receipt: receipt,
      tracking_ref: tracking,
      paid_at: payment === 'paid' && order.payment_status !== 'paid' ? new Date().toISOString() : order.paid_at,
      status_history: changed
        ? [...history, { status, at: new Date().toISOString(), note: `Updated by admin` }]
        : history,
    });

    if (order.private_id) {
      await db.entities.OrderPrivate.update(order.private_id, { admin_note: note });
    }

    setSaving(false);
    onUpdated();
    onClose();
  };

  const printInvoice = () => {
    const rows = (order.items || [])
      .map(
        (item) =>
          `<tr><td>${item.qty} × ${item.name}${item.size ? ` (${item.size})` : ''}${
            item.color ? ` ${item.color}` : ''
          }</td><td style="text-align:right">${formatKES(item.price * item.qty)}</td></tr>`
      )
      .join('');

    const html = `<!doctype html><html><head><title>${order.order_number}</title>
      <style>body{font-family:Helvetica,Arial,sans-serif;color:#171717;padding:40px;max-width:720px;margin:auto}
      h1{font-size:22px;letter-spacing:.2em}h2{font-size:13px;text-transform:uppercase;letter-spacing:.2em;color:#777;margin-top:32px}
      table{width:100%;border-collapse:collapse;margin-top:12px;font-size:13px}td{padding:8px 0;border-bottom:1px solid #e7e1d6}
      .row{display:flex;justify-content:space-between;font-size:13px;padding:4px 0}.total{font-size:16px;font-weight:bold}</style></head><body>
      <h1>BEV COLLECTIONS</h1>
      <p style="font-size:12px;color:#777">Invoice ${order.order_number} · ${new Date(order.created_date).toLocaleDateString('en-KE')}</p>
      <h2>Customer</h2>
      <p style="font-size:13px">${order.customer_name}<br>${order.phone}<br>${order.email || ''}<br>
      ${[order.estate, order.town, order.county, order.address].filter(Boolean).join(', ')}</p>
      <h2>Items</h2><table>${rows}</table>
      <div style="margin-top:20px">
        <div class="row"><span>Subtotal</span><span>${formatKES(order.subtotal)}</span></div>
        ${order.discount ? `<div class="row"><span>Discount</span><span>-${formatKES(order.discount)}</span></div>` : ''}
        <div class="row"><span>Delivery</span><span>${formatKES(order.delivery_fee)}</span></div>
        <div class="row total"><span>Total</span><span>${formatKES(order.total)}</span></div>
        <div class="row"><span>Payment</span><span>${PAYMENT_LABELS[order.payment_status] || order.payment_status}${
          order.mpesa_receipt ? ` · ${order.mpesa_receipt}` : ''
        }</span></div>
      </div>
      <p style="margin-top:32px;font-size:11px;color:#777">Thank you for shopping with Bev Collections.</p>
      </body></html>`;

    const win = window.open('', '_blank');
    if (win) {
      win.document.write(html);
      win.document.close();
      win.print();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-foreground/40">
      <div className="h-full w-full max-w-xl overflow-y-auto bg-background p-6 md:p-8">
        <div className="flex items-start justify-between">
          <div>
            <p className="eyebrow">Order</p>
            <h2 className="mt-2 font-display text-3xl tracking-tight">{order.order_number}</h2>
            <p className="mt-1 text-xs text-muted-foreground">
              {new Date(order.created_date).toLocaleString('en-KE')}
            </p>
          </div>
          <button type="button" onClick={onClose} className="text-xs uppercase tracking-[0.2em]">
            Close
          </button>
        </div>

        <div className="mt-6 border border-border/70 p-4 text-sm">
          <p>{order.customer_name}</p>
          <p className="text-muted-foreground">{order.phone}</p>
          {order.email && <p className="text-muted-foreground">{order.email}</p>}
          <p className="mt-2 text-muted-foreground">
            {[order.estate, order.town, order.county, order.address].filter(Boolean).join(', ')}
          </p>
          {order.notes && <p className="mt-2 italic text-muted-foreground">“{order.notes}”</p>}
        </div>

        <h3 className="eyebrow mt-6">Items</h3>
        <ul className="mt-3 divide-y divide-border/70 border-t border-border/70">
          {(order.items || []).map((item, index) => (
            <li key={index} className="flex justify-between gap-3 py-2.5 text-sm">
              <span>
                {item.qty} × {item.name}
                {item.size && <span className="text-muted-foreground"> · {item.size}</span>}
                {item.color && <span className="text-muted-foreground"> · {item.color}</span>}
              </span>
              <span>{formatKES(item.price * item.qty)}</span>
            </li>
          ))}
        </ul>
        <div className="mt-3 space-y-1 border-t border-border/70 pt-3 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Subtotal</span>
            <span>{formatKES(order.subtotal)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Delivery</span>
            <span>{formatKES(order.delivery_fee)}</span>
          </div>
          {order.discount > 0 && (
            <div className="flex justify-between text-accent">
              <span>Discount</span>
              <span>-{formatKES(order.discount)}</span>
            </div>
          )}
          <div className="flex justify-between pt-2 text-base">
            <span>Total</span>
            <span className="font-medium">{formatKES(order.total)}</span>
          </div>
        </div>

        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          <label className="block">
            <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
              Payment status
            </span>
            <select value={payment} onChange={(e) => setPayment(e.target.value)} className="field mt-2">
              <option value="pending">Pending</option>
              <option value="paid">Paid</option>
              <option value="failed">Failed</option>
            </select>
          </label>
          <label className="block">
            <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
              Order status
            </span>
            <select value={status} onChange={(e) => setStatus(e.target.value)} className="field mt-2">
              {ORDER_STATUSES.map((item) => (
                <option key={item.value} value={item.value}>
                  {item.label}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
              M-Pesa receipt
            </span>
            <input value={receipt} onChange={(e) => setReceipt(e.target.value)} className="field mt-2" placeholder="e.g. SLK7XYZ123" />
          </label>
          <label className="block">
            <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
              Tracking reference
            </span>
            <input value={tracking} onChange={(e) => setTracking(e.target.value)} className="field mt-2" />
          </label>
          <label className="block sm:col-span-2">
            <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
              Internal note
            </span>
            <textarea value={note} onChange={(e) => setNote(e.target.value)} rows={2} className="field mt-2 resize-none" />
          </label>
        </div>

        <div className="mt-6 flex flex-wrap gap-3">
          <button type="button" onClick={save} disabled={saving} className="btn-primary disabled:opacity-60">
            {saving ? 'Saving…' : 'Save changes'}
          </button>
          <button type="button" onClick={printInvoice} className="btn-outline">
            Print invoice
          </button>
        </div>

        {Array.isArray(order.status_history) && order.status_history.length > 0 && (
          <div className="mt-8">
            <h3 className="eyebrow">History</h3>
            <ul className="mt-3 space-y-2 text-xs text-muted-foreground">
              {order.status_history.map((entry, index) => (
                <li key={index}>
                  {statusLabel(entry.status)} · {new Date(entry.at).toLocaleString('en-KE')}
                  {entry.note ? ` — ${entry.note}` : ''}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}