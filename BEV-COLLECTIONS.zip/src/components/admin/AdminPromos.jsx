const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState } from 'react';

import { formatKES } from '@/lib/shop';

const asArray = (result) => (Array.isArray(result) ? result : result?.items || []);

export default function AdminPromos() {
  const [coupons, setCoupons] = useState([]);
  const [zones, setZones] = useState([]);
  const [coupon, setCoupon] = useState({ code: '', type: 'percent', value: '', min_purchase: '', expires_at: '' });
  const [zone, setZone] = useState({ name: '', counties: '', fee: '', free_threshold: '', eta: '', is_pickup: false });
  const [saving, setSaving] = useState(false);

  const load = async () => {
    const [couponPage, zonePage] = await Promise.all([
      db.entities.Coupon.filter({}, { limit: 100 }),
      db.entities.DeliveryZone.filter({}, { sort: 'sort_order' }),
    ]);
    setCoupons(asArray(couponPage));
    setZones(asArray(zonePage));
  };

  useEffect(() => {
    load().catch(() => {});
  }, []);

  const addCoupon = async (event) => {
    event.preventDefault();
    if (!coupon.code.trim() || !coupon.value) return;
    setSaving(true);
    try {
      await db.entities.Coupon.create({
        code: coupon.code.trim().toUpperCase(),
        type: coupon.type,
        value: Number(coupon.value),
        min_purchase: Number(coupon.min_purchase) || 0,
        expires_at: coupon.expires_at || '',
        is_active: true,
        usage_count: 0,
      });
      setCoupon({ code: '', type: 'percent', value: '', min_purchase: '', expires_at: '' });
      load();
    } finally {
      setSaving(false);
    }
  };

  const addZone = async (event) => {
    event.preventDefault();
    if (!zone.name.trim()) return;
    setSaving(true);
    try {
      await db.entities.DeliveryZone.create({
        name: zone.name.trim(),
        counties: zone.counties.split(',').map((item) => item.trim()).filter(Boolean),
        fee: Number(zone.fee) || 0,
        free_threshold: Number(zone.free_threshold) || 0,
        eta: zone.eta,
        is_pickup: zone.is_pickup,
        is_active: true,
        sort_order: zones.length + 1,
      });
      setZone({ name: '', counties: '', fee: '', free_threshold: '', eta: '', is_pickup: false });
      load();
    } finally {
      setSaving(false);
    }
  };

  const updateZone = async (record, changes) => {
    await db.entities.DeliveryZone.update(record.id, changes);
    load();
  };

  const toggleCoupon = async (record) => {
    await db.entities.Coupon.update(record.id, { is_active: record.is_active === false });
    load();
  };

  const removeCoupon = async (record) => {
    if (!window.confirm(`Delete code ${record.code}?`)) return;
    await db.entities.Coupon.delete(record.id);
    load();
  };

  const removeZone = async (record) => {
    if (!window.confirm(`Delete ${record.name}?`)) return;
    await db.entities.DeliveryZone.delete(record.id);
    load();
  };

  return (
    <div className="grid gap-12 lg:grid-cols-2">
      <section>
        <h1 className="font-display text-3xl tracking-tight">Discount codes</h1>
        <p className="mt-1 text-xs text-muted-foreground">
          Codes apply at checkout. Leave the expiry empty for no end date.
        </p>

        <form onSubmit={addCoupon} className="mt-6 border border-border/70 bg-card p-5">
          <div className="grid gap-4 sm:grid-cols-2">
            <label className="block">
              <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Code</span>
              <input
                value={coupon.code}
                onChange={(event) => setCoupon((p) => ({ ...p, code: event.target.value }))}
                className="field mt-2 uppercase"
                placeholder="WELCOME10"
              />
            </label>
            <label className="block">
              <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Type</span>
              <select
                value={coupon.type}
                onChange={(event) => setCoupon((p) => ({ ...p, type: event.target.value }))}
                className="field mt-2"
              >
                <option value="percent">Percentage off</option>
                <option value="fixed">Fixed amount off</option>
              </select>
            </label>
            <label className="block">
              <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                {coupon.type === 'percent' ? 'Percent (%)' : 'Amount (KSh)'}
              </span>
              <input
                value={coupon.value}
                onChange={(event) => setCoupon((p) => ({ ...p, value: event.target.value }))}
                className="field mt-2"
                inputMode="numeric"
              />
            </label>
            <label className="block">
              <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                Minimum spend (KSh)
              </span>
              <input
                value={coupon.min_purchase}
                onChange={(event) => setCoupon((p) => ({ ...p, min_purchase: event.target.value }))}
                className="field mt-2"
                inputMode="numeric"
              />
            </label>
            <label className="block sm:col-span-2">
              <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                Expiry date
              </span>
              <input
                type="date"
                value={coupon.expires_at}
                onChange={(event) => setCoupon((p) => ({ ...p, expires_at: event.target.value }))}
                className="field mt-2"
              />
            </label>
          </div>
          <button type="submit" disabled={saving} className="btn-primary mt-4 disabled:opacity-60">
            Create code
          </button>
        </form>

        <div className="mt-6 divide-y divide-border/70 border-t border-border/70">
          {coupons.length === 0 && (
            <p className="py-4 text-sm text-muted-foreground">No codes yet.</p>
          )}
          {coupons.map((record) => (
            <div key={record.id} className="flex items-center justify-between gap-3 py-3 text-sm">
              <div>
                <p className="tracking-[0.1em]">{record.code}</p>
                <p className="text-xs text-muted-foreground">
                  {record.type === 'percent' ? `${record.value}% off` : `${formatKES(record.value)} off`}
                  {Number(record.min_purchase) > 0 ? ` · min ${formatKES(record.min_purchase)}` : ''}
                  {record.expires_at ? ` · until ${record.expires_at}` : ''}
                </p>
              </div>
              <div className="flex items-center gap-4">
                <button
                  type="button"
                  onClick={() => toggleCoupon(record)}
                  className="text-[10px] uppercase tracking-[0.16em] text-muted-foreground hover:text-foreground"
                >
                  {record.is_active === false ? 'Activate' : 'Deactivate'}
                </button>
                <button
                  type="button"
                  onClick={() => removeCoupon(record)}
                  className="text-[10px] uppercase tracking-[0.16em] text-destructive"
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h1 className="font-display text-3xl tracking-tight">Delivery areas</h1>
        <p className="mt-1 text-xs text-muted-foreground">
          Set the fee and free-delivery threshold for each area. These appear at checkout.
        </p>

        <form onSubmit={addZone} className="mt-6 border border-border/70 bg-card p-5">
          <div className="grid gap-4 sm:grid-cols-2">
            <label className="block">
              <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Area name</span>
              <input
                value={zone.name}
                onChange={(event) => setZone((p) => ({ ...p, name: event.target.value }))}
                className="field mt-2"
                placeholder="Nairobi CBD"
              />
            </label>
            <label className="block">
              <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Delivery fee (KSh)</span>
              <input
                value={zone.fee}
                onChange={(event) => setZone((p) => ({ ...p, fee: event.target.value }))}
                className="field mt-2"
                inputMode="numeric"
              />
            </label>
            <label className="block sm:col-span-2">
              <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                Counties covered (comma separated)
              </span>
              <input
                value={zone.counties}
                onChange={(event) => setZone((p) => ({ ...p, counties: event.target.value }))}
                className="field mt-2"
                placeholder="Nairobi"
              />
            </label>
            <label className="block">
              <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                Free delivery over (KSh)
              </span>
              <input
                value={zone.free_threshold}
                onChange={(event) => setZone((p) => ({ ...p, free_threshold: event.target.value }))}
                className="field mt-2"
                inputMode="numeric"
              />
            </label>
            <label className="block">
              <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                Delivery timeline
              </span>
              <input
                value={zone.eta}
                onChange={(event) => setZone((p) => ({ ...p, eta: event.target.value }))}
                className="field mt-2"
                placeholder="1–2 working days"
              />
            </label>
          </div>
          <label className="mt-4 flex items-center gap-2 text-xs">
            <input
              type="checkbox"
              checked={zone.is_pickup}
              onChange={(event) => setZone((p) => ({ ...p, is_pickup: event.target.checked }))}
              className="h-3.5 w-3.5 accent-foreground"
            />
            This is a pickup option
          </label>
          <button type="submit" disabled={saving} className="btn-primary mt-4 disabled:opacity-60">
            Add delivery area
          </button>
        </form>

        <div className="mt-6 divide-y divide-border/70 border-t border-border/70">
          {zones.length === 0 && (
            <p className="py-4 text-sm text-muted-foreground">
              No delivery areas yet — add Nairobi and the counties you serve.
            </p>
          )}
          {zones.map((record) => (
            <div key={record.id} className="flex flex-wrap items-center justify-between gap-3 py-3 text-sm">
              <div>
                <p>{record.name}</p>
                <p className="text-xs text-muted-foreground">
                  {record.is_pickup ? 'Pickup' : formatKES(record.fee)}
                  {Number(record.free_threshold) > 0 ? ` · free over ${formatKES(record.free_threshold)}` : ''}
                  {record.eta ? ` · ${record.eta}` : ''}
                </p>
                <input
                  defaultValue={(record.counties || []).join(', ')}
                  onBlur={(event) =>
                    updateZone(record, {
                      counties: event.target.value.split(',').map((item) => item.trim()).filter(Boolean),
                    })
                  }
                  className="field mt-2 text-xs"
                  placeholder="Counties"
                />
              </div>
              <button
                type="button"
                onClick={() => removeZone(record)}
                className="text-[10px] uppercase tracking-[0.16em] text-destructive"
              >
                Delete
              </button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}