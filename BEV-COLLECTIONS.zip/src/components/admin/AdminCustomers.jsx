const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useMemo, useState } from 'react';

import { formatKES } from '@/lib/shop';
import { attachCustomerDetails } from '@/lib/orderData';

const asArray = (result) => (Array.isArray(result) ? result : result?.items || []);

export default function AdminCustomers() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    db.entities.Order
      .filter({}, { sort: '-created_date', limit: 300 })
      .then(async (page) => setOrders(await attachCustomerDetails(asArray(page))))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const customers = useMemo(() => {
    const groups = new Map();
    orders.forEach((order) => {
      const key = order.phone || order.customer_name;
      if (!key) return;
      const existing = groups.get(key) || {
        name: order.customer_name,
        phone: order.phone,
        email: order.email,
        orders: 0,
        spent: 0,
        last: order.created_date,
        county: order.county,
      };
      existing.orders += 1;
      if (order.payment_status === 'paid') existing.spent += Number(order.total || 0);
      if (new Date(order.created_date) > new Date(existing.last)) {
        existing.last = order.created_date;
        existing.county = order.county || existing.county;
      }
      groups.set(key, existing);
    });
    return [...groups.values()].sort((a, b) => b.spent - a.spent);
  }, [orders]);

  const visible = customers.filter((customer) =>
    [customer.name, customer.phone, customer.email, customer.county]
      .filter(Boolean)
      .join(' ')
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl tracking-tight">Customers</h1>
          <p className="mt-1 text-xs text-muted-foreground">
            {customers.length} people have ordered from Bev Collections.
          </p>
        </div>
        <input
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Search name, phone or county"
          className="field w-full sm:w-64"
        />
      </div>

      <div className="mt-5 overflow-x-auto rounded-lg border border-border/60 bg-card">
        <table className="w-full min-w-[680px] text-left text-[13px]">
          <thead className="border-b border-border/60 text-[9px] uppercase tracking-[0.16em] text-muted-foreground">
            <tr>
              <th className="px-4 py-3 font-normal">Customer</th>
              <th className="px-4 py-3 font-normal">Phone</th>
              <th className="px-4 py-3 font-normal">County</th>
              <th className="px-4 py-3 font-normal">Orders</th>
              <th className="px-4 py-3 font-normal">Spent</th>
              <th className="px-4 py-3 font-normal">Last order</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border/50">
            {loading && (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">
                  Loading…
                </td>
              </tr>
            )}
            {!loading && visible.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">
                  No customers yet.
                </td>
              </tr>
            )}
            {visible.map((customer) => (
              <tr key={customer.phone || customer.name}>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2.5">
                    <span className="grid h-7 w-7 place-items-center rounded-full bg-secondary text-[10px] text-muted-foreground">
                      {String(customer.name || '?').charAt(0).toUpperCase()}
                    </span>
                    <div>
                      <p>{customer.name}</p>
                      {customer.email && (
                        <p className="text-[11px] text-muted-foreground">{customer.email}</p>
                      )}
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3 text-muted-foreground">{customer.phone || '—'}</td>
                <td className="px-4 py-3 text-muted-foreground">{customer.county || '—'}</td>
                <td className="px-4 py-3">{customer.orders}</td>
                <td className="px-4 py-3">{formatKES(customer.spent)}</td>
                <td className="px-4 py-3 text-muted-foreground">
                  {new Date(customer.last).toLocaleDateString('en-KE', {
                    day: '2-digit',
                    month: 'short',
                    year: 'numeric',
                  })}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}