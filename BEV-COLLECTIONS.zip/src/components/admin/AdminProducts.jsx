const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useCallback, useEffect, useState } from 'react';

import { formatKES } from '@/lib/shop';
import ProductEditor from './ProductEditor';
import { DEFAULT_CATEGORIES } from '@/data/catalog';

const asArray = (result) => (Array.isArray(result) ? result : result?.items || []);

export default function AdminProducts({ initialSearch = '' }) {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [editing, setEditing] = useState(null);
  const [showEditor, setShowEditor] = useState(false);
  const [search, setSearch] = useState(initialSearch);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setSearch(initialSearch);
  }, [initialSearch]);

  const load = useCallback(async () => {
    const [productPage, categoryList] = await Promise.all([
      db.entities.Product.filter({}, { sort: '-created_date', limit: 300 }),
      db.entities.Category.list('sort_order'),
    ]);
    setProducts(asArray(productPage));
    const cats = asArray(categoryList);
    setCategories(cats.length ? cats : DEFAULT_CATEGORIES);
    setLoading(false);
  }, []);

  useEffect(() => {
    load().catch(() => setLoading(false));
  }, [load]);

  const remove = async (product) => {
    if (!window.confirm(`Delete ${product.name}? This cannot be undone.`)) return;
    await db.entities.Product.delete(product.id);
    load();
  };

  const visible = products.filter((product) =>
    [product.name, product.sku, product.category].filter(Boolean).join(' ').toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl tracking-tight">Products</h1>
          <p className="mt-1 text-xs text-muted-foreground">{products.length} in catalogue</p>
        </div>
        <div className="flex items-center gap-2">
          <input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search products"
            className="field w-48"
          />
          <button
            type="button"
            onClick={() => {
              setEditing(null);
              setShowEditor(true);
            }}
            className="btn-primary"
          >
            Add product
          </button>
        </div>
      </div>

      <div className="mt-6 overflow-x-auto border border-border/70">
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead className="bg-card text-[9px] uppercase tracking-[0.2em] text-muted-foreground">
            <tr>
              <th className="px-4 py-3">Product</th>
              <th className="px-4 py-3">Category</th>
              <th className="px-4 py-3">Price</th>
              <th className="px-4 py-3">Stock</th>
              <th className="px-4 py-3">Flags</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-border/70">
            {loading && (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">
                  Loading…
                </td>
              </tr>
            )}
            {!loading && visible.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">
                  No products yet. Add your first piece.
                </td>
              </tr>
            )}
            {visible.map((product) => (
              <tr key={product.id} className="align-middle">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    {product.images?.[0] && (
                      <img src={product.images[0]} alt="" className="h-10 w-10 object-cover" />
                    )}
                    <div>
                      <p>{product.name}</p>
                      <p className="text-xs text-muted-foreground">{product.sku || product.slug}</p>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3 text-xs capitalize text-muted-foreground">{product.category}</td>
                <td className="px-4 py-3">{formatKES(product.price)}</td>
                <td className="px-4 py-3">
                  {Number(product.stock || 0) + (product.variations || []).reduce((s, v) => s + Number(v.stock || 0), 0)}
                </td>
                <td className="px-4 py-3">
                  <div className="flex flex-wrap gap-1 text-[9px] uppercase tracking-[0.14em]">
                    {product.is_new_arrival && <span className="bg-secondary px-1.5 py-0.5">New</span>}
                    {product.is_featured && <span className="bg-secondary px-1.5 py-0.5">Featured</span>}
                    {product.is_best_seller && <span className="bg-secondary px-1.5 py-0.5">Best</span>}
                    {product.is_active === false && <span className="bg-secondary px-1.5 py-0.5">Hidden</span>}
                  </div>
                </td>
                <td className="px-4 py-3 text-right">
                  <button
                    type="button"
                    onClick={() => {
                      setEditing(product);
                      setShowEditor(true);
                    }}
                    className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground hover:text-foreground"
                  >
                    Edit
                  </button>
                  <button
                    type="button"
                    onClick={() => remove(product)}
                    className="ml-4 text-[10px] uppercase tracking-[0.18em] text-destructive"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showEditor && (
        <ProductEditor
          product={editing}
          categories={categories}
          onClose={() => setShowEditor(false)}
          onSaved={load}
        />
      )}
    </div>
  );
}