const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState } from 'react';
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { ArrowDownRight, ArrowUpRight, CreditCard, ShoppingBag, TrendingUp, Users } from 'lucide-react';

import { formatKES } from '@/lib/shop';
import { attachCustomerDetails } from '@/lib/orderData';
import { PaymentBadge, OrderStatusBadge } from './OrderBadges';

const asArray = (result) => (Array.isArray(result) ? result : result?.items || []);
const DAY = 86400000;

const sum = (list, key) => list.reduce((total, item) => total + Number(item[key] || 0), 0);

const trend = (current, previous) => {
  if (!previous) return null;
  return Math.round(((current - previous) / previous) * 100);
};

function KpiCard({ label, value, delta, icon: Icon, hint }) {
  const up = delta !== null && delta >= 0;
  return (
    <div className="rounded-lg border border-border/60 bg-card p-4">
      <div className="flex items-start justify-between">
        <p className="text-[10px] uppercase tracking-[0.16em] text-muted-foreground">{label}</p>
        <span className="grid h-8 w-8 place-items-center rounded-md bg-secondary text-muted-foreground">
          <Icon className="h-4 w-4" strokeWidth={1.6} />
        </span>
      </div>
      <p className="mt-3 font-display text-2xl tracking-tight md:text-[26px]">{value}</p>
      <div className="mt-1.5 flex items-center gap-1.5 text-[11px]">
        {delta === null ? (
          <span className="text-muted-foreground">{hint || 'No comparison yet'}</span>
        ) : (
          <>
            <span
              className={`flex items-center gap-0.5 font-medium ${
                up ? 'text-emerald-600' : 'text-destructive'
              }`}
            >
              {up ? (
                <ArrowUpRight className="h-3 w-3" strokeWidth={2} />
              ) : (
                <ArrowDownRight className="h-3 w-3" strokeWidth={2} />
              )}
              {Math.abs(delta)}%
            </span>
            <span className="text-muted-foreground">vs previous 30 days</span>
          </>
        )}
      </div>
    </div>
  );
}

export default function AdminOverview({ onNavigate }) {
  const [orders, setOrders] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      db.entities.Order.filter({}, { sort: '-created_date', limit: 300 }),
      db.entities.Product.filter({}, { limit: 300 }),
    ])
      .then(async ([orderPage, productPage]) => {
        setOrders(await attachCustomerDetails(asArray(orderPage)));
        setProducts(asArray(productPage));
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const now = Date.now();
  const paid = orders.filter((order) => order.payment_status === 'paid');
  const within = (order, from, to) => {
    const time = new Date(order.created_date).getTime();
    return time >= from && time < to;
  };

  const recent = paid.filter((order) => within(order, now - 30 * DAY, now));
  const previous = paid.filter((order) => within(order, now - 60 * DAY, now - 30 * DAY));

  const revenue = sum(recent, 'total');
  const previousRevenue = sum(previous, 'total');
  const customers = new Set(recent.map((order) => order.phone).filter(Boolean)).size;
  const previousCustomers = new Set(previous.map((order) => order.phone).filter(Boolean)).size;
  const average = recent.length ? Math.round(revenue / recent.length) : 0;
  const previousAverage = previous.length ? Math.round(previousRevenue / previous.length) : 0;
  const pending = orders.filter((order) => order.payment_status === 'pending');

  const chartData = Array.from({ length: 14 }, (_, index) => {
    const dayStart = new Date();
    dayStart.setHours(0, 0, 0, 0);
    const start = dayStart.getTime() - (13 - index) * DAY;
    const end = start + DAY;
    const dayOrders = paid.filter((order) => within(order, start, end));
    return {
      day: new Date(start).toLocaleDateString('en-KE', { day: '2-digit', month: 'short' }),
      orders: dayOrders.length,
      income: sum(dayOrders, 'total'),
    };
  });

  const bestSellers = [...products]
    .sort((a, b) => Number(b.sold_count || 0) - Number(a.sold_count || 0))
    .slice(0, 4);

  const customerRows = Object.values(
    paid.reduce((groups, order) => {
      const key = order.phone || order.customer_name;
      if (!groups[key]) {
        groups[key] = { name: order.customer_name, phone: order.phone, total: 0, orders: 0 };
      }
      groups[key].total += Number(order.total || 0);
      groups[key].orders += 1;
      return groups;
    }, {})
  )
    .sort((a, b) => b.total - a.total)
    .slice(0, 4);

  if (loading) {
    return (
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {[...Array(4)].map((_, index) => (
          <div key={index} className="h-28 animate-pulse rounded-lg bg-card" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl tracking-tight">Welcome back</h1>
          <p className="mt-1 text-xs text-muted-foreground">
            Here is what is happening at Bev Collections today.
          </p>
        </div>
        <button
          type="button"
          onClick={() => onNavigate('orders')}
          className="rounded-md border border-border bg-card px-3.5 py-2 text-[10px] uppercase tracking-[0.18em] text-muted-foreground hover:text-foreground"
        >
          View all orders
        </button>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <KpiCard
          label="Sales revenue"
          value={formatKES(revenue)}
          delta={trend(revenue, previousRevenue)}
          icon={TrendingUp}
        />
        <KpiCard
          label="Paid orders"
          value={recent.length}
          delta={trend(recent.length, previous.length)}
          icon={ShoppingBag}
        />
        <KpiCard
          label="Customers"
          value={customers}
          delta={trend(customers, previousCustomers)}
          icon={Users}
        />
        <KpiCard
          label="Average order"
          value={formatKES(average)}
          delta={trend(average, previousAverage)}
          icon={CreditCard}
        />
        <KpiCard
          label="Awaiting payment"
          value={pending.length}
          delta={null}
          hint="Reconcile in Orders"
          icon={ShoppingBag}
        />
      </div>

      <div className="grid gap-4 xl:grid-cols-3">
        <div className="rounded-lg border border-border/60 bg-card p-4 xl:col-span-2">
          <div className="flex items-center justify-between">
            <h2 className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
              Orders & income · last 14 days
            </h2>
            <div className="flex items-center gap-4 text-[10px] uppercase tracking-[0.14em]">
              <span className="flex items-center gap-1.5 text-muted-foreground">
                <span className="h-1.5 w-1.5 rounded-full bg-foreground" /> Orders
              </span>
              <span className="flex items-center gap-1.5 text-muted-foreground">
                <span className="h-1.5 w-1.5 rounded-full bg-sage" /> Income
              </span>
            </div>
          </div>
          <div className="mt-4 h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ left: -18, right: 6, top: 6 }}>
                <defs>
                  <linearGradient id="income" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#a3a892" stopOpacity={0.55} />
                    <stop offset="100%" stopColor="#a3a892" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e7e2d9" vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 10 }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 10 }} tickLine={false} axisLine={false} width={48} />
                <Tooltip
                  contentStyle={{
                    fontSize: 12,
                    borderRadius: 6,
                    border: '1px solid #e7e2d9',
                  }}
                  formatter={(value, name) => (name === 'income' ? formatKES(value) : value)}
                />
                <Area
                  type="monotone"
                  dataKey="income"
                  stroke="#a3a892"
                  fill="url(#income)"
                  strokeWidth={2}
                />
                <Area
                  type="monotone"
                  dataKey="orders"
                  stroke="#171717"
                  fill="transparent"
                  strokeWidth={2}
                  strokeDasharray="4 3"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-lg border border-border/60 bg-card p-4">
          <div className="flex items-center justify-between">
            <h2 className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
              Most selling
            </h2>
            <button
              type="button"
              onClick={() => onNavigate('products')}
              className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground hover:text-foreground"
            >
              All
            </button>
          </div>
          <div className="mt-3 space-y-3">
            {bestSellers.map((product) => (
              <div key={product.id} className="flex items-center gap-3">
                {product.images?.[0] ? (
                  <img src={product.images[0]} alt="" className="h-10 w-10 rounded-md object-cover" />
                ) : (
                  <span className="h-10 w-10 rounded-md bg-secondary" />
                )}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13px]">{product.name}</p>
                  <p className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                    {product.sku || product.slug}
                  </p>
                </div>
                <span className="text-[11px] text-muted-foreground">
                  {product.sold_count || 0} sold
                </span>
              </div>
            ))}
            {bestSellers.length === 0 && (
              <p className="py-4 text-xs text-muted-foreground">No products yet.</p>
            )}
          </div>

          <div className="mt-5 border-t border-border/60 pt-4">
            <h3 className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
              Top customers
            </h3>
            <div className="mt-3 space-y-2.5">
              {customerRows.map((customer) => (
                <div key={customer.phone || customer.name} className="flex items-center gap-2.5">
                  <span className="grid h-7 w-7 place-items-center rounded-full bg-secondary text-[10px] text-muted-foreground">
                    {String(customer.name || '?').charAt(0).toUpperCase()}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[12px]">{customer.name}</p>
                    <p className="text-[10px] text-muted-foreground">{customer.orders} orders</p>
                  </div>
                  <span className="text-[11px] text-muted-foreground">
                    {formatKES(customer.total)}
                  </span>
                </div>
              ))}
              {customerRows.length === 0 && (
                <p className="text-xs text-muted-foreground">No paid orders yet.</p>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="rounded-lg border border-border/60 bg-card">
        <div className="flex items-center justify-between px-4 py-3">
          <h2 className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
            Recent orders
          </h2>
          <button
            type="button"
            onClick={() => onNavigate('orders')}
            className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground hover:text-foreground"
          >
            View all
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-left text-[13px]">
            <thead className="border-y border-border/60 text-[9px] uppercase tracking-[0.16em] text-muted-foreground">
              <tr>
                <th className="px-4 py-2.5 font-normal">Product</th>
                <th className="px-4 py-2.5 font-normal">Customer</th>
                <th className="px-4 py-2.5 font-normal">Order</th>
                <th className="px-4 py-2.5 font-normal">Date</th>
                <th className="px-4 py-2.5 font-normal">Status</th>
                <th className="px-4 py-2.5 text-right font-normal">Total</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/50">
              {orders.slice(0, 6).map((order) => {
                const first = order.items?.[0];
                return (
                  <tr key={order.id} className="align-middle">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        {first?.image ? (
                          <img src={first.image} alt="" className="h-8 w-8 rounded object-cover" />
                        ) : (
                          <span className="h-8 w-8 rounded bg-secondary" />
                        )}
                        <span className="max-w-[160px] truncate">{first?.name || 'Order'}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{order.customer_name}</td>
                    <td className="px-4 py-3 text-muted-foreground">{order.order_number}</td>
                    <td className="px-4 py-3 text-muted-foreground">
                      {new Date(order.created_date).toLocaleDateString('en-KE', {
                        day: '2-digit',
                        month: 'short',
                      })}
                    </td>
                    <td className="px-4 py-3">
                      <OrderStatusBadge status={order.order_status} />
                    </td>
                    <td className="px-4 py-3 text-right">
                      <p>{formatKES(order.total)}</p>
                      <PaymentBadge status={order.payment_status} />
                    </td>
                  </tr>
                );
              })}
              {orders.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-xs text-muted-foreground">
                    No orders yet — share your store link to get started.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}