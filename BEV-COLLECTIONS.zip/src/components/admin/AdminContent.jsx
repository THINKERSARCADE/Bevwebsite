const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState } from 'react';

import { useStore } from '@/context/StoreContext';
import ImageUploadField from './ImageUploadField';
import { DEFAULT_CONTENT } from '@/data/catalog';

const TEXT_FIELDS = [
  ['announcement', 'Announcement bar'],
  ['hero_eyebrow', 'Hero — small label'],
  ['hero_subheading', 'Hero — supporting text'],
  ['hero_cta_label', 'Hero — primary button'],
  ['hero_cta_link', 'Hero — primary link'],
  ['hero_cta2_label', 'Hero — secondary button'],
  ['hero_cta2_link', 'Hero — secondary link'],
  ['promo_heading', 'Promo heading'],
  ['promo_text', 'Promo text'],
  ['promo_cta_label', 'Promo button'],
  ['promo_cta_link', 'Promo link'],
];

export default function AdminContent() {
  const { content, contentRecord, reload } = useStore();
  const [form, setForm] = useState(DEFAULT_CONTENT);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setForm({ ...DEFAULT_CONTENT, ...content });
  }, [content]);

  const update = (key, value) => {
    setForm((previous) => ({ ...previous, [key]: value }));
    setSaved(false);
  };

  const save = async (event) => {
    event.preventDefault();
    setSaving(true);
    const payload = { ...form, key: 'site' };
    delete payload.id;
    delete payload.created_date;
    delete payload.updated_date;
    delete payload.created_by_id;

    try {
      if (contentRecord?.id) await db.entities.SiteContent.update(contentRecord.id, payload);
      else await db.entities.SiteContent.create(payload);
      await reload();
      setSaved(true);
    } finally {
      setSaving(false);
    }
  };

  const setGallery = (index, value) => {
    const gallery = [...(form.gallery || [])];
    gallery[index] = value;
    update('gallery', gallery.filter(Boolean));
  };

  return (
    <form onSubmit={save}>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl tracking-tight">Storefront content</h1>
          <p className="mt-1 text-xs text-muted-foreground">
            Everything here appears on the live homepage, footer and contact pages.
          </p>
        </div>
        <button type="submit" disabled={saving} className="btn-primary disabled:opacity-60">
          {saving ? 'Saving…' : saved ? 'Saved' : 'Save changes'}
        </button>
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-2">
        <section className="border border-border/70 bg-card p-5">
          <h2 className="eyebrow">Announcement & hero</h2>
          <div className="mt-4 space-y-4">
            {TEXT_FIELDS.map(([key, label]) => (
              <label key={key} className="block">
                <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                  {label}
                </span>
                <input
                  value={form[key] || ''}
                  onChange={(event) => update(key, event.target.value)}
                  className="field mt-2"
                />
              </label>
            ))}
            <label className="block">
              <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                Hero headline (line breaks kept)
              </span>
              <textarea
                value={form.hero_heading || ''}
                onChange={(event) => update('hero_heading', event.target.value)}
                rows={2}
                className="field mt-2 resize-none"
              />
            </label>
            <ImageUploadField
              label="Hero image"
              value={form.hero_image}
              onChange={(value) => update('hero_image', value)}
            />
            <ImageUploadField
              label="Promo banner image"
              value={form.promo_image}
              onChange={(value) => update('promo_image', value)}
            />
          </div>
        </section>

        <section className="border border-border/70 bg-card p-5">
          <h2 className="eyebrow">Business details</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            {[
              ['business_name', 'Business name'],
              ['phone', 'Phone number'],
              ['whatsapp', 'WhatsApp number'],
              ['email', 'Business email'],
              ['instagram', 'Instagram URL'],
              ['facebook', 'Facebook URL'],
              ['tiktok', 'TikTok URL'],
              ['address', 'Physical address'],
            ].map(([key, label]) => (
              <label key={key} className="block">
                <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                  {label}
                </span>
                <input
                  value={form[key] || ''}
                  onChange={(event) => update(key, event.target.value)}
                  className="field mt-2"
                  placeholder={key === 'whatsapp' ? '2547XXXXXXXX' : ''}
                />
              </label>
            ))}
          </div>

          <h2 className="eyebrow mt-8">About & policies</h2>
          <div className="mt-4 space-y-4">
            {[
              ['about_text', 'About Bev Collections'],
              ['delivery_note', 'Delivery note'],
              ['returns_note', 'Returns note'],
              ['payment_instructions', 'Payment instructions'],
            ].map(([key, label]) => (
              <label key={key} className="block">
                <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                  {label}
                </span>
                <textarea
                  value={form[key] || ''}
                  onChange={(event) => update(key, event.target.value)}
                  rows={3}
                  className="field mt-2 resize-none"
                />
              </label>
            ))}
          </div>
        </section>

        <section className="border border-border/70 bg-card p-5">
          <h2 className="eyebrow">Inspiration gallery</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            {[0, 1, 2, 3].map((index) => (
              <ImageUploadField
                key={index}
                label={`Image ${index + 1}`}
                value={form.gallery?.[index] || ''}
                onChange={(value) => setGallery(index, value)}
              />
            ))}
          </div>
        </section>

        <section className="border border-border/70 bg-card p-5">
          <h2 className="eyebrow">Search engine listing</h2>
          <div className="mt-4 space-y-4">
            <label className="block">
              <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                Page title
              </span>
              <input
                value={form.seo_title || ''}
                onChange={(event) => update('seo_title', event.target.value)}
                className="field mt-2"
              />
            </label>
            <label className="block">
              <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                Meta description
              </span>
              <textarea
                value={form.seo_description || ''}
                onChange={(event) => update('seo_description', event.target.value)}
                rows={3}
                className="field mt-2 resize-none"
              />
            </label>
            <p className="text-[10px] leading-relaxed text-muted-foreground">
              Product pages automatically use the product name and description as their title and
              meta description.
            </p>
          </div>
        </section>
      </div>
    </form>
  );
}