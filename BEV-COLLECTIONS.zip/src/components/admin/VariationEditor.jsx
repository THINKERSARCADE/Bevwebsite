const keyFor = (size, color) => `${size || 'one'}::${color || 'any'}`;

export default function VariationEditor({ sizes, colors, variations, onChange }) {
  const sizeList = sizes.length ? sizes : ['One Size'];
  const colorList = colors.length ? colors : ['Default'];

  const stockOf = (size, color) => {
    const sizeKey = sizes.length ? size : '';
    const colorKey = colors.length ? color : '';
    const match = (variations || []).find(
      (variation) =>
        (variation.size || '') === sizeKey && (variation.color || '') === colorKey
    );
    return match ? String(match.stock ?? 0) : '';
  };

  const setStock = (size, color, value) => {
    const sizeKey = sizes.length ? size : '';
    const colorKey = colors.length ? color : '';
    const others = (variations || []).filter(
      (variation) =>
        !((variation.size || '') === sizeKey && (variation.color || '') === colorKey)
    );
    if (value === '') {
      onChange(others);
      return;
    }
    onChange([...others, { size: sizeKey, color: colorKey, stock: Math.max(0, Number(value) || 0) }]);
  };

  const total = (variations || []).reduce((sum, variation) => sum + Number(variation.stock || 0), 0);

  return (
    <div>
      <div className="flex items-center justify-between">
        <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
          Stock per size & colour
        </span>
        <span className="text-[11px] text-muted-foreground">{total} in total</span>
      </div>
      <div className="no-scrollbar mt-3 overflow-x-auto">
        <table className="w-full min-w-[420px] border border-border/70 text-left text-xs">
          <thead className="bg-secondary/50 text-[9px] uppercase tracking-[0.14em] text-muted-foreground">
            <tr>
              <th className="px-2.5 py-2 font-normal">Size</th>
              {colorList.map((color) => (
                <th key={color} className="px-2.5 py-2 font-normal">
                  {color}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border/60">
            {sizeList.map((size) => (
              <tr key={size}>
                <td className="px-2.5 py-2 text-muted-foreground">{size}</td>
                {colorList.map((color) => (
                  <td key={keyFor(size, color)} className="px-1.5 py-1.5">
                    <input
                      value={stockOf(size, color)}
                      onChange={(event) => setStock(size, color, event.target.value)}
                      placeholder="0"
                      inputMode="numeric"
                      className="w-16 border border-border bg-background px-2 py-1.5 text-xs outline-none focus:border-foreground"
                    />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-2 text-[10px] leading-relaxed text-muted-foreground">
        Each size and colour keeps its own stock. Customers can only buy what is available in the
        variation they pick.
      </p>
    </div>
  );
}