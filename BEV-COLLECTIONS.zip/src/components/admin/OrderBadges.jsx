const ORDER_COLORS = {
  processing: 'bg-amber-100 text-amber-800',
  ready_for_dispatch: 'bg-blue-100 text-blue-800',
  dispatched: 'bg-indigo-100 text-indigo-800',
  out_for_delivery: 'bg-sky-100 text-sky-800',
  delivered: 'bg-emerald-100 text-emerald-800',
  cancelled: 'bg-neutral-200 text-neutral-700',
  returned: 'bg-red-100 text-red-800',
};

const PAYMENT_COLORS = {
  paid: 'bg-emerald-100 text-emerald-800',
  pending: 'bg-amber-100 text-amber-800',
  failed: 'bg-red-100 text-red-800',
};

const label = (value) => String(value || '').replace(/_/g, ' ');

export function OrderStatusBadge({ status }) {
  return (
    <span
      className={`inline-block rounded-full px-2 py-0.5 text-[10px] capitalize ${
        ORDER_COLORS[status] || 'bg-secondary text-muted-foreground'
      }`}
    >
      {label(status)}
    </span>
  );
}

export function PaymentBadge({ status }) {
  return (
    <span
      className={`inline-block rounded-full px-2 py-0.5 text-[9px] uppercase tracking-[0.12em] ${
        PAYMENT_COLORS[status] || 'bg-secondary text-muted-foreground'
      }`}
    >
      {label(status)}
    </span>
  );
}