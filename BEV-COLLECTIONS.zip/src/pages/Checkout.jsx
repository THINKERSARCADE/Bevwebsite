const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Check, ChevronLeft, MessageCircle } from 'lucide-react';

import { useCart } from '@/context/CartContext';
import { useStore } from '@/context/StoreContext';
import { formatKES } from '@/lib/shop';
import {
  buildOrderSummary,
  generateOrderNumber,
  normalizePhone,
  phoneFingerprint,
  whatsappLink,
} from '@/lib/orders';
import usePageMeta from '@/lib/usePageMeta';
import { sendNewOrderEmail } from '@/lib/orderNotifications';
import { cn } from '@/lib/utils';

const asArray = (result) => (Array.isArray(result) ? result : result?.items || []);

const FALLBACK_COUNTIES = [
  'Nairobi', 'Kiambu', 'Machakos', 'Kajiado', 'Nakuru', 'Mombasa', 'Kisumu', 'Uasin Gishu',
  'Nyeri', 'Meru', 'Kisii', 'Kakamega', 'Bungoma', 'Kilifi', 'Laikipia', 'Murang’a',
];

const emptyForm = {
  customer_name: '',
  phone: '',
  email: '',
  county: '',
  town: '',
  estate: '',
  address: '',
  notes: '',
};

export default function Checkout() {
  const { items, subtotal, clearCart } = useCart();
  const { zones, content } = useStore();
  const navigate = useNavigate();

  const [form, setForm] = useState(emptyForm);
  const [zoneId, setZoneId] = useState('');
  const [method, setMethod] = useState('mpesa');
  const [errors, setErrors] = useState({});
  const [placing, setPlacing] = useState(false);
  const [placed, setPlaced] = useState(null);
  const [couponInput, setCouponInput] = useState('');
  const [coupon, setCoupon] = useState(null);
  const [couponMessage, setCouponMessage] = useState('');

  usePageMeta('Checkout — Bev Collections', 'Complete your Bev Collections order securely.');

  const zone = zones.find((item) => item.id === zoneId) || null;
  const counties = [...new Set(zones.flatMap((item) => item.counties || []))];
  const countyOptions = counties.length ? counties : FALLBACK_COUNTIES;

  const discount = coupon
    ? coupon.type === 'percent'
      ? Math.round((subtotal * Number(coupon.value)) / 100)
      : Math.min(Number(coupon.value), subtotal)
    : 0;

  const baseFee = zone ? Number(zone.fee || 0) : 0;
  const qualifiesFree =
    zone && Number(zone.free_threshold) > 0 && subtotal >= Number(zone.free_threshold);
  const deliveryFee = zone?.is_pickup || qualifiesFree ? 0 : baseFee;
  const total = Math.max(0, subtotal - discount) + deliveryFee;

  const update = (key, value) => {
    setForm((previous) => ({ ...previous, [key]: value }));
    setErrors((previous) => ({ ...previous, [key]: undefined }));
  };

  const applyCoupon = async () => {
    const code = couponInput.trim().toUpperCase();
    if (!code) return;
    try {
      const records = asArray(await db.entities.Coupon.filter({ code, is_active: true }));
      const found = records[0];
      if (!found) {
        setCoupon(null);
        setCouponMessage('That code is not valid.');
        return;
      }
      if (found.expires_at && new Date(found.expires_at) < new Date()) {
        setCoupon(null);
        setCouponMessage('That code has expired.');
        return;
      }
      if (Number(found.min_purchase) > 0 && subtotal < Number(found.min_purchase)) {
        setCoupon(null);
        setCouponMessage(`Spend ${formatKES(found.min_purchase)} to use this code.`);
        return;
      }
      setCoupon(found);
      setCouponMessage(`Code ${found.code} applied.`);
    } catch {
      setCouponMessage('Could not check that code. Try again.');
    }
  };

  const validate = () => {
    const next = {};
    if (!form.customer_name.trim()) next.customer_name = 'Enter your full name.';
    if (!/^(?:\+?254|0)?7\d{8}$|^(?:\+?254|0)?1\d{8}$/.test(form.phone.replace(/\s/g, '')))
      next.phone = 'Enter a valid Kenyan mobile number.';
    if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email))
      next.email = 'Enter a valid email address.';
    if (!zone) next.zone = 'Choose your delivery area.';
    if (zone && !zone.is_pickup) {
      if (!form.county.trim()) next.county = 'Select your county.';
      if (!form.town.trim()) next.town = 'Enter your town.';
      if (!form.address.trim()) next.address = 'Enter your delivery address.';
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const placeOrder = async (event) => {
    event.preventDefault();
    if (!validate()) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    setPlacing(true);
    const orderNumber = generateOrderNumber();

    const contact = {
      order_number: orderNumber,
      customer_name: form.customer_name.trim(),
      phone: normalizePhone(form.phone),
      email: form.email.trim(),
      estate: form.estate,
      address: form.address,
      notes: form.notes,
    };

    const payload = {
      order_number: orderNumber,
      county: form.county,
      town: form.town,
      phone_fingerprint: await phoneFingerprint(form.phone),
      items: items.map((item) => ({
        product_id: item.product_id,
        name: item.name,
        slug: item.slug,
        image: item.image,
        size: item.size,
        color: item.color,
        qty: item.qty,
        price: item.price,
      })),
      subtotal,
      delivery_fee: deliveryFee,
      discount,
      total,
      coupon_code: coupon?.code || '',
      delivery_method: zone?.is_pickup ? 'pickup' : 'delivery',
      delivery_zone: zone?.name || '',
      payment_method: method,
      payment_status: 'pending',
      order_status: 'processing',
      status_history: [
        { status: 'order_placed', at: new Date().toISOString(), note: 'Order placed by customer' },
      ],
    };

    try {
      await db.entities.OrderPrivate.create(contact);
      const order = await db.entities.Order.create(payload);
      if (coupon) {
        await db.entities.Coupon.update(coupon.id, {
          usage_count: Number(coupon.usage_count || 0) + 1,
        }).catch(() => {});
      }
      clearCart();
      setPlaced({ ...order, ...contact });
      sendNewOrderEmail({ ...order, ...contact });
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (error) {
      setErrors({ submit: 'We could not save your order. Please try again.' });
    } finally {
      setPlacing(false);
    }
  };

  if (placed) {
    const message = buildOrderSummary(placed);
    return (
      <div className="shell max-w-3xl py-16 md:py-24">
        <div className="flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-full bg-foreground text-background">
            <Check className="h-5 w-5" strokeWidth={1.6} />
          </span>
          <p className="eyebrow">Order received</p>
        </div>
        <h1 className="mt-6 font-display text-4xl tracking-[-0.02em] md:text-5xl">
          Thank you, {placed.customer_name.split(' ')[0]}.
        </h1>
        <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
          Your order <span className="text-foreground">{placed.order_number}</span> is saved. Our
          team will call or message you on {placed.phone} to confirm delivery and complete payment.
        </p>

        <div className="mt-8 border border-border/70 bg-card p-6">
          <div className="flex items-center justify-between border-b border-border/70 pb-4">
            <span className="eyebrow">Order total</span>
            <span className="font-display text-2xl">{formatKES(placed.total)}</span>
          </div>
          <div className="mt-4">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Payment</span>
              <span className="text-[10px] uppercase tracking-[0.2em] text-accent">
                {placed.payment_method === 'whatsapp' ? 'On WhatsApp' : 'Awaiting M-Pesa'}
              </span>
            </div>
            <p className="mt-3 text-xs leading-relaxed text-muted-foreground">
              {content.payment_instructions}
            </p>
            <p className="mt-3 rounded-md border border-border/70 bg-secondary/40 p-3 text-xs leading-relaxed">
              Quote <span className="text-foreground">{placed.order_number}</span> when paying. Our
              team sends the M-Pesa request and confirms the moment it clears — stock is reserved
              for this order.
            </p>
          </div>
        </div>

        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <Link to={`/order/${placed.order_number}`} className="btn-primary">
            Track this order
          </Link>
          {content.whatsapp && (
            <a
              href={whatsappLink(content.whatsapp, message)}
              target="_blank"
              rel="noreferrer"
              className="btn-outline"
            >
              <MessageCircle className="h-4 w-4" strokeWidth={1.5} />
              Send order on WhatsApp
            </a>
          )}
        </div>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="shell py-24 text-center">
        <h1 className="font-display text-4xl tracking-tight">Your bag is empty</h1>
        <p className="mt-3 text-sm text-muted-foreground">
          Add a few pieces before checking out.
        </p>
        <Link to="/shop" className="btn-primary mt-8">
          Shop the collection
        </Link>
      </div>
    );
  }

  return (
    <div className="shell py-10 md:py-16">
      <button
        type="button"
        onClick={() => navigate('/cart')}
        className="flex items-center gap-2 text-[10px] uppercase tracking-[0.22em] text-muted-foreground hover:text-foreground"
      >
        <ChevronLeft className="h-3.5 w-3.5" strokeWidth={1.6} /> Back to bag
      </button>

      <h1 className="mt-6 font-display text-4xl tracking-[-0.02em] md:text-5xl">Checkout</h1>

      <form onSubmit={placeOrder} className="mt-10 grid gap-12 md:grid-cols-12">
        <div className="space-y-12 md:col-span-7">
          <section>
            <h2 className="eyebrow">01 — Your details</h2>
            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <Field label="Full name" error={errors.customer_name} className="sm:col-span-2">
                <input
                  value={form.customer_name}
                  onChange={(event) => update('customer_name', event.target.value)}
                  className="field"
                  placeholder="Jane Wanjiku"
                  autoComplete="name"
                />
              </Field>
              <Field label="Phone (M-Pesa)" error={errors.phone}>
                <input
                  value={form.phone}
                  onChange={(event) => update('phone', event.target.value)}
                  className="field"
                  placeholder="07xx xxx xxx"
                  inputMode="tel"
                  autoComplete="tel"
                  type="tel"
                />
              </Field>
              <Field label="Email (optional)" error={errors.email}>
                <input
                  value={form.email}
                  onChange={(event) => update('email', event.target.value)}
                  className="field"
                  placeholder="you@email.com"
                  inputMode="email"
                  autoComplete="email"
                  type="email"
                />
              </Field>
            </div>
          </section>

          <section>
            <h2 className="eyebrow">02 — Delivery</h2>
            <div className="mt-6 space-y-3">
              {zones.length === 0 && (
                <p className="border border-border/70 p-4 text-xs leading-relaxed text-muted-foreground">
                  Delivery areas are being set up. Place your order and our team will confirm the
                  delivery fee and timing with you directly.
                </p>
              )}
              {zones.map((option) => (
                <label
                  key={option.id}
                  className={cn(
                    'flex cursor-pointer items-start justify-between gap-4 border p-4 transition-colors',
                    zoneId === option.id ? 'border-foreground' : 'border-border hover:border-foreground/50'
                  )}
                >
                  <div>
                    <p className="text-sm">{option.name}</p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {option.is_pickup ? 'Collect in person' : option.eta || 'Delivery timeframe confirmed by our team'}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs">
                      {option.is_pickup
                        ? 'Pickup'
                        : Number(option.fee) > 0
                        ? formatKES(option.fee)
                        : 'Confirmed by us'}
                    </p>
                    {Number(option.free_threshold) > 0 && (
                      <p className="mt-1 text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
                        Free over {formatKES(option.free_threshold)}
                      </p>
                    )}
                  </div>
                  <input
                    type="radio"
                    name="zone"
                    className="sr-only"
                    checked={zoneId === option.id}
                    onChange={() => setZoneId(option.id)}
                  />
                </label>
              ))}
              {errors.zone && <p className="text-xs text-destructive">{errors.zone}</p>}
            </div>

            {zone && !zone.is_pickup && (
              <div className="mt-6 grid gap-4 sm:grid-cols-2">
                <Field label="County" error={errors.county}>
                  <select
                    value={form.county}
                    onChange={(event) => update('county', event.target.value)}
                    className="field"
                    autoComplete="address-level1"
                  >
                    <option value="">Select county</option>
                    {countyOptions.map((county) => (
                      <option key={county} value={county}>
                        {county}
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label="Town / area" error={errors.town}>
                  <input
                    value={form.town}
                    onChange={(event) => update('town', event.target.value)}
                    className="field"
                    placeholder="Westlands"
                    autoComplete="address-level2"
                  />
                </Field>
                <Field label="Estate / building">
                  <input
                    value={form.estate}
                    onChange={(event) => update('estate', event.target.value)}
                    className="field"
                    placeholder="Kilimani, Sable Court"
                    autoComplete="address-line2"
                  />
                </Field>
                <Field label="Delivery address" error={errors.address}>
                  <input
                    value={form.address}
                    onChange={(event) => update('address', event.target.value)}
                    className="field"
                    placeholder="Street, house or apartment number"
                    autoComplete="street-address"
                  />
                </Field>
                <Field label="Delivery instructions (optional)" className="sm:col-span-2">
                  <textarea
                    value={form.notes}
                    onChange={(event) => update('notes', event.target.value)}
                    rows={3}
                    className="field resize-none"
                    placeholder="Gate code, landmark, preferred time…"
                  />
                </Field>
              </div>
            )}
          </section>

          <section>
            <h2 className="eyebrow">03 — Payment</h2>
            <div className="mt-6 space-y-3">
              <label
                className={cn(
                  'flex cursor-pointer items-start gap-4 border p-4 transition-colors',
                  method === 'mpesa' ? 'border-foreground' : 'border-border hover:border-foreground/50'
                )}
              >
                <input
                  type="radio"
                  name="method"
                  checked={method === 'mpesa'}
                  onChange={() => setMethod('mpesa')}
                  className="mt-1 accent-foreground"
                />
                <div>
                  <p className="text-sm">M-Pesa</p>
                  <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                    We record your order and send the M-Pesa payment request to your number. You pay
                    only once you approve it on your phone.
                  </p>
                </div>
              </label>
              <label
                className={cn(
                  'flex cursor-pointer items-start gap-4 border p-4 transition-colors',
                  method === 'whatsapp' ? 'border-foreground' : 'border-border hover:border-foreground/50'
                )}
              >
                <input
                  type="radio"
                  name="method"
                  checked={method === 'whatsapp'}
                  onChange={() => setMethod('whatsapp')}
                  className="mt-1 accent-foreground"
                />
                <div>
                  <p className="text-sm">Complete on WhatsApp</p>
                  <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                    We save your order and open a WhatsApp chat with the full summary so you can
                    confirm and pay with our team.
                  </p>
                </div>
              </label>
            </div>
          </section>
        </div>

        <aside className="md:col-span-5 md:pl-8">
          <div className="border border-border/70 bg-card p-6 md:sticky md:top-28 md:p-7">
            <h2 className="eyebrow">Order summary</h2>
            <ul className="mt-5 space-y-3">
              {items.map((item) => (
                <li key={item.key} className="flex justify-between gap-3 text-sm">
                  <span className="text-muted-foreground">
                    {item.qty} × {item.name}
                    {item.size ? ` · ${item.size}` : ''}
                    {item.color ? ` · ${item.color}` : ''}
                  </span>
                  <span className="shrink-0">{formatKES(item.price * item.qty)}</span>
                </li>
              ))}
            </ul>

            <div className="mt-6 border-t border-border/70 pt-5">
              <label className="eyebrow" htmlFor="coupon">
                Discount code
              </label>
              <div className="mt-3 flex gap-2">
                <input
                  id="coupon"
                  value={couponInput}
                  onChange={(event) => setCouponInput(event.target.value)}
                  className="field flex-1"
                  placeholder="Enter code"
                />
                <button
                  type="button"
                  onClick={applyCoupon}
                  className="border border-border px-4 text-[10px] uppercase tracking-[0.2em] transition-colors hover:border-foreground"
                >
                  Apply
                </button>
              </div>
              {couponMessage && (
                <p className={cn('mt-2 text-xs', coupon ? 'text-accent' : 'text-destructive')}>
                  {couponMessage}
                </p>
              )}
            </div>

            <dl className="mt-6 space-y-2.5 border-t border-border/70 pt-5 text-sm">
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Subtotal</dt>
                <dd>{formatKES(subtotal)}</dd>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-accent">
                  <dt>Discount</dt>
                  <dd>-{formatKES(discount)}</dd>
                </div>
              )}
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Delivery</dt>
                <dd>
                  {zone
                    ? deliveryFee > 0
                      ? formatKES(deliveryFee)
                      : zone.is_pickup
                      ? 'Pickup'
                      : 'Confirmed by us'
                    : 'Select area'}
                </dd>
              </div>
              <div className="flex items-baseline justify-between border-t border-border/70 pt-4">
                <dt className="text-[10px] uppercase tracking-[0.24em]">Total</dt>
                <dd className="font-display text-2xl">{formatKES(total)}</dd>
              </div>
            </dl>

            {errors.submit && <p className="mt-4 text-xs text-destructive">{errors.submit}</p>}

            <button type="submit" disabled={placing} className="btn-primary mt-6 w-full disabled:opacity-60">
              {placing ? 'Placing order…' : method === 'whatsapp' ? 'Place order & chat' : 'Place order'}
            </button>
            <p className="mt-4 text-[10px] leading-relaxed uppercase tracking-[0.16em] text-muted-foreground">
              No account needed. Your details are only used to fulfil this order.
            </p>
          </div>
        </aside>
      </form>
    </div>
  );
}

function Field({ label, error, children, className }) {
  return (
    <label className={cn('block', className)}>
      <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">{label}</span>
      <div className="mt-2">{children}</div>
      {error && <p className="mt-1.5 text-xs text-destructive">{error}</p>}
    </label>
  );
}