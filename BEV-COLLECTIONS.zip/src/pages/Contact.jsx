const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState } from 'react';
import { Mail, MapPin, MessageCircle, Phone } from 'lucide-react';

import { useStore } from '@/context/StoreContext';
import { whatsappLink } from '@/lib/orders';
import usePageMeta from '@/lib/usePageMeta';

const FAQS = [
  {
    q: 'How long does delivery take?',
    a: 'Nairobi orders are usually dispatched within 24 hours. County deliveries typically arrive within 2–4 working days after payment is confirmed.',
  },
  {
    q: 'How do I pay?',
    a: 'We accept M-Pesa. Place your order with your Safaricom number and our team sends the payment request; you approve it on your phone.',
  },
  {
    q: 'Can I exchange a size?',
    a: 'Yes. Unworn items with their tags can be exchanged within 7 days of delivery. Message us with your order number to arrange it.',
  },
  {
    q: 'Do you have a physical shop?',
    a: 'We sell online and deliver countrywide. If you would like to view a piece before ordering, message us and we will advise.',
  },
  {
    q: 'Are the sizes true to fit?',
    a: 'Shoe sizes are in EU sizing and clothing is standard XS–XXL. If you are between sizes, message us before ordering and we will guide you.',
  },
];

export default function Contact() {
  const { content } = useStore();
  const [form, setForm] = useState({ name: '', email: '', phone: '', subject: '', message: '' });
  const [errors, setErrors] = useState({});
  const [sent, setSent] = useState(false);
  const [saving, setSaving] = useState(false);

  usePageMeta(
    'Contact Bev Collections',
    'Talk to Bev Collections about orders, sizing, delivery or returns.'
  );

  const update = (key, value) => {
    setForm((previous) => ({ ...previous, [key]: value }));
    setErrors((previous) => ({ ...previous, [key]: undefined }));
  };

  const submit = async (event) => {
    event.preventDefault();
    const next = {};
    if (!form.name.trim()) next.name = 'Enter your name.';
    if (!form.message.trim()) next.message = 'Tell us how we can help.';
    if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email))
      next.email = 'Enter a valid email address.';
    setErrors(next);
    if (Object.keys(next).length) return;

    setSaving(true);
    try {
      await db.entities.ContactMessage.create({
        name: form.name.trim(),
        email: form.email.trim(),
        phone: form.phone.trim(),
        subject: form.subject.trim(),
        message: form.message.trim(),
        status: 'new',
      });
      setSent(true);
      setForm({ name: '', email: '', phone: '', subject: '', message: '' });
    } catch {
      setErrors({ submit: 'Could not send that just now. Please try again or message us on WhatsApp.' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <div className="shell py-14 md:py-20">
        <p className="eyebrow">Customer care</p>
        <h1 className="mt-4 font-display text-4xl tracking-[-0.02em] md:text-5xl">Contact us</h1>
        <p className="mt-4 max-w-lg text-sm leading-relaxed text-muted-foreground">
          Questions about an order, sizing or delivery? We are happy to help — usually within a few
          hours during business days.
        </p>
      </div>

      <div className="shell grid gap-12 pb-20 md:grid-cols-12">
        <div className="md:col-span-5">
          <div className="space-y-6 border border-border/70 bg-card p-6">
            {content.phone && (
              <a href={`tel:${content.phone}`} className="flex items-start gap-3 text-sm">
                <Phone className="mt-0.5 h-4 w-4 text-accent" strokeWidth={1.4} />
                {content.phone}
              </a>
            )}
            {content.whatsapp && (
              <a
                href={whatsappLink(content.whatsapp, 'Hello Bev Collections, I have a question.')}
                target="_blank"
                rel="noreferrer"
                className="flex items-start gap-3 text-sm"
              >
                <MessageCircle className="mt-0.5 h-4 w-4 text-accent" strokeWidth={1.4} />
                WhatsApp us
              </a>
            )}
            {content.email && (
              <a href={`mailto:${content.email}`} className="flex items-start gap-3 text-sm">
                <Mail className="mt-0.5 h-4 w-4 text-accent" strokeWidth={1.4} />
                {content.email}
              </a>
            )}
            <p className="flex items-start gap-3 text-sm text-muted-foreground">
              <MapPin className="mt-0.5 h-4 w-4 text-accent" strokeWidth={1.4} />
              {content.address || 'Nairobi, Kenya'}
            </p>
            {!content.phone && !content.whatsapp && !content.email && (
              <p className="text-xs leading-relaxed text-muted-foreground">
                Contact details are being added. Send us a message with the form and we will reply
                to the address you leave.
              </p>
            )}
          </div>

          <div className="mt-8">
            <h2 className="eyebrow">Frequently asked</h2>
            <div className="mt-4 divide-y divide-border/70 border-t border-border/70">
              {FAQS.map((faq) => (
                <details key={faq.q} className="group py-4">
                  <summary className="flex cursor-pointer items-center justify-between text-sm">
                    {faq.q}
                    <span className="ml-4 text-muted-foreground transition-transform group-open:rotate-45">
                      +
                    </span>
                  </summary>
                  <p className="mt-3 text-xs leading-relaxed text-muted-foreground">{faq.a}</p>
                </details>
              ))}
            </div>
          </div>
        </div>

        <div className="md:col-span-7">
          <div className="border border-border/70 p-6 md:p-8">
            {sent ? (
              <div>
                <h2 className="font-display text-2xl tracking-tight">Message received</h2>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  Thank you for reaching out. Our team will get back to you shortly.
                </p>
              </div>
            ) : (
              <form onSubmit={submit} className="space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <label className="block">
                    <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                      Name
                    </span>
                    <input
                      value={form.name}
                      onChange={(event) => update('name', event.target.value)}
                      className="field mt-2"
                    />
                    {errors.name && <p className="mt-1.5 text-xs text-destructive">{errors.name}</p>}
                  </label>
                  <label className="block">
                    <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                      Phone
                    </span>
                    <input
                      value={form.phone}
                      onChange={(event) => update('phone', event.target.value)}
                      className="field mt-2"
                    />
                  </label>
                  <label className="block">
                    <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                      Email
                    </span>
                    <input
                      value={form.email}
                      onChange={(event) => update('email', event.target.value)}
                      className="field mt-2"
                    />
                    {errors.email && <p className="mt-1.5 text-xs text-destructive">{errors.email}</p>}
                  </label>
                  <label className="block">
                    <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                      Subject
                    </span>
                    <input
                      value={form.subject}
                      onChange={(event) => update('subject', event.target.value)}
                      className="field mt-2"
                      placeholder="Order, sizing, delivery…"
                    />
                  </label>
                </div>
                <label className="block">
                  <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                    Message
                  </span>
                  <textarea
                    value={form.message}
                    onChange={(event) => update('message', event.target.value)}
                    rows={5}
                    className="field mt-2 resize-none"
                  />
                  {errors.message && (
                    <p className="mt-1.5 text-xs text-destructive">{errors.message}</p>
                  )}
                </label>
                {errors.submit && <p className="text-xs text-destructive">{errors.submit}</p>}
                <button type="submit" disabled={saving} className="btn-primary w-full disabled:opacity-60">
                  {saving ? 'Sending…' : 'Send message'}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}