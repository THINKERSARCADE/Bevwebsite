import { useState } from 'react';
import AdminGate from '@/components/admin/AdminGate';
import AdminShell from '@/components/admin/AdminShell';
import AdminOverview from '@/components/admin/AdminOverview';
import AdminProducts from '@/components/admin/AdminProducts';
import AdminOrders from '@/components/admin/AdminOrders';
import AdminCustomers from '@/components/admin/AdminCustomers';
import AdminContent from '@/components/admin/AdminContent';
import AdminCatalog from '@/components/admin/AdminCatalog';
import AdminPromos from '@/components/admin/AdminPromos';
import AdminInbox from '@/components/admin/AdminInbox';

export default function Admin() {
  const [tab, setTab] = useState('overview');
  const [productSearch, setProductSearch] = useState('');

  return (
    <AdminGate>
      <AdminShell
        active={tab}
        onNavigate={setTab}
        onSearch={(term) => {
          setProductSearch(term);
          setTab('products');
        }}
      >
        {tab === 'overview' && <AdminOverview onNavigate={setTab} />}
        {tab === 'products' && <AdminProducts initialSearch={productSearch} />}
        {tab === 'orders' && <AdminOrders />}
        {tab === 'customers' && <AdminCustomers />}
        {tab === 'promos' && <AdminPromos />}
        {tab === 'catalogue' && <AdminCatalog />}
        {tab === 'storefront' && <AdminContent />}
        {tab === 'inbox' && <AdminInbox />}
      </AdminShell>
    </AdminGate>
  );
}