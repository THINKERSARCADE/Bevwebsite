const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useMemo, useState } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';

import ProductCard from '@/components/store/ProductCard';
import FilterPanel from '@/components/store/FilterPanel';
import usePageMeta from '@/lib/usePageMeta';
import { formatKES } from '@/lib/shop';
import MobileFilterSheet from '@/components/store/MobileFilterSheet';
import { SlidersHorizontal, X } from 'lucide-react';

const asArray = (result) => (Array.isArray(result) ? result : result?.items || []);

const TITLES = {
  shoes: 'Shoes',
  clothing: 'Clothing',
  handbags: 'Handbags',
  accessories: 'Accessories',
};

export default function Shop() {
  const { category: categorySlug } = useParams();
  const [params, setParams] = useSearchParams();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);

  const q = params.get('q') || '';
  const filter = params.get('filter') || '';
  const sort = params.get('sort') || 'newest';
  const collection = params.get('collection') || '';
  const size = params.get('size') || '';
  const color = params.get('color') || '';
  const maxPrice = params.get('max') || '';
  const availableOnly = params.get('available') === '1';

  useEffect(() => {
    let alive = true;
    db.entities.Product
      .filter({}, { sort: '-created_date', limit: 200 })
      .then((page) => {
        if (alive) setProducts(asArray(page));
      })
      .catch(() => {
        if (alive) setProducts([]);
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [categorySlug, filter, sort]);

  const title = categorySlug ? TITLES[categorySlug] || 'Shop' : 'Shop All';
  usePageMeta(
    `${title} — Bev Collections`,
    `Shop ${title.toLowerCase()} at Bev Collections. Carefully selected fashion delivered across Kenya.`
  );

  const visible = useMemo(() => {
    let list = products.filter((product) => product.is_active !== false);

    if (categorySlug) list = list.filter((product) => product.category === categorySlug);
    if (collection) list = list.filter((product) => product.collection === collection);
    if (filter === 'new') list = list.filter((product) => product.is_new_arrival);
    if (filter === 'sale')
      list = list.filter((product) => product.compare_price > product.price);
    if (filter === 'best') list = list.filter((product) => product.is_best_seller);
    if (size)
      list = list.filter((product) => (product.sizes || []).includes(size) || (product.variations || []).some((v) => v.size === size));
    if (color)
      list = list.filter((product) => (product.colors || []).includes(color));
    if (maxPrice) list = list.filter((product) => Number(product.price) <= Number(maxPrice));
    if (availableOnly)
      list = list.filter(
        (product) =>
          Number(product.stock || 0) > 0 ||
          (product.variations || []).some((v) => Number(v.stock) > 0)
      );
    if (q) {
      const term = q.toLowerCase();
      list = list.filter((product) =>
        [product.name, product.sku, product.description, ...(product.tags || [])]
          .filter(Boolean)
          .join(' ')
          .toLowerCase()
          .includes(term)
      );
    }

    const sorted = [...list];
    if (sort === 'price-asc') sorted.sort((a, b) => a.price - b.price);
    else if (sort === 'price-desc') sorted.sort((a, b) => b.price - a.price);
    else if (sort === 'popular') sorted.sort((a, b) => (b.sold_count || 0) - (a.sold_count || 0));
    else sorted.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));

    return sorted;
  }, [products, categorySlug, collection, filter, size, color, maxPrice, availableOnly, q, sort]);

  const allSizes = [...new Set(products.flatMap((p) => p.sizes || []))];
  const allColors = [...new Set(products.flatMap((p) => p.colors || []))];

  const setParam = (key, value) => {
    const next = new URLSearchParams(params);
    if (value) next.set(key, value);
    else next.delete(key);
    setParams(next, { replace: true });
  };

  const applyFilters = (draft) => {
    const next = new URLSearchParams(params);
    const entries = {
      size: draft.size,
      color: draft.color,
      max: draft.max,
      available: draft.available ? '1' : '',
    };
    Object.entries(entries).forEach(([key, value]) => {
      if (value) next.set(key, value);
      else next.delete(key);
    });
    setParams(next, { replace: true });
  };

  const clearFilters = () => {
    const next = new URLSearchParams(params);
    ['size', 'color', 'max', 'available'].forEach((key) => next.delete(key));
    setParams(next, { replace: true });
  };

  const activeFilters = [
    size && { key: 'size', label: `Size ${size}` },
    color && { key: 'color', label: color },
    maxPrice && { key: 'max', label: `Under ${formatKES(maxPrice)}` },
    availableOnly && { key: 'available', label: 'In stock' },
  ].filter(Boolean);

  return (
    <div>
      <div className="border-b border-border/70 bg-card">
        <div className="shell py-12 md:py-16">
          <p className="eyebrow">{filter === 'sale' ? 'Special offers' : 'The collection'}</p>
          <h1 className="mt-4 font-display text-4xl tracking-[-0.02em] md:text-6xl">
            {filter === 'sale' ? 'Sale' : filter === 'new' ? 'New Arrivals' : title}
          </h1>
          <p className="mt-4 max-w-lg text-sm leading-relaxed text-muted-foreground">
            {q
              ? `Results for “${q}”`
              : 'Carefully selected shoes, clothing, handbags and accessories. Delivery countrywide.'}
          </p>
        </div>
      </div>

      <div className="shell grid gap-10 py-10 md:grid-cols-12 md:py-14">
        <aside className="hidden md:col-span-3 md:block">
          <FilterPanel
            sizes={allSizes}
            colors={allColors}
            maxPrice={maxPrice}
            size={size}
            color={color}
            availableOnly={availableOnly}
            onChange={setParam}
          />
        </aside>

        <div className="md:col-span-9">
          <div className="sticky top-[76px] z-30 -mx-5 flex items-center justify-between gap-3 border-b border-border/70 bg-background/95 px-5 py-3 backdrop-blur-md md:static md:mx-0 md:border-b md:bg-transparent md:px-0 md:pb-4 md:backdrop-blur-none">
            <p className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
              {visible.length} {visible.length === 1 ? 'piece' : 'pieces'}
            </p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowFilters(true)}
                aria-label={`Filter products${activeFilters.length ? `, ${activeFilters.length} active` : ''}`}
                className="flex min-h-11 items-center gap-2 border border-border px-3 text-[10px] uppercase tracking-[0.18em] active:bg-secondary md:hidden"
              >
                <SlidersHorizontal className="h-4 w-4" strokeWidth={1.5} />
                Filter
                {activeFilters.length > 0 && (
                  <span className="grid h-5 min-w-5 place-items-center rounded-full bg-foreground px-1 text-[9px] text-background">
                    {activeFilters.length}
                  </span>
                )}
              </button>
              <label className="flex min-h-11 items-center gap-2 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                Sort
                <select
                  value={sort}
                  onChange={(event) => setParam('sort', event.target.value)}
                  aria-label="Sort products"
                  className="min-h-11 border border-border bg-background px-2 text-[10px] tracking-[0.14em] text-foreground outline-none md:min-h-0 md:py-1.5"
                >
                  <option value="newest">Newest</option>
                  <option value="popular">Popularity</option>
                  <option value="price-asc">Price: low to high</option>
                  <option value="price-desc">Price: high to low</option>
                </select>
              </label>
            </div>
          </div>

          {activeFilters.length > 0 && (
            <div className="mt-4 flex flex-wrap items-center gap-2 md:hidden">
              {activeFilters.map((item) => (
                <button
                  key={item.key}
                  type="button"
                  onClick={() => setParam(item.key, '')}
                  className="flex min-h-9 items-center gap-1.5 rounded-full border border-border px-3 text-[10px] uppercase tracking-[0.14em] text-foreground"
                  aria-label={`Remove ${item.label} filter`}
                >
                  {item.label}
                  <X className="h-3 w-3" strokeWidth={1.8} />
                </button>
              ))}
              <button
                type="button"
                onClick={clearFilters}
                className="min-h-9 px-1 text-[10px] uppercase tracking-[0.14em] text-muted-foreground underline underline-offset-4"
              >
                Clear all
              </button>
            </div>
          )}

          <MobileFilterSheet
            open={showFilters}
            onOpenChange={setShowFilters}
            sizes={allSizes}
            colors={allColors}
            values={{ size, color, max: maxPrice, available: availableOnly }}
            onApply={applyFilters}
            onClear={clearFilters}
          />

          {loading ? (
            <div className="grid grid-cols-2 gap-x-3 gap-y-8 pt-6 sm:gap-x-4 sm:gap-y-10 lg:grid-cols-3">
              {[0, 1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="animate-pulse">
                  <div className="aspect-[4/5] w-full bg-secondary" />
                  <div className="mt-4 h-3 w-2/3 bg-secondary" />
                  <div className="mt-2 h-3 w-1/3 bg-secondary" />
                </div>
              ))}
            </div>
          ) : visible.length === 0 ? (
            <div className="py-24 text-center">
              <p className="font-display text-2xl">Nothing matches those filters</p>
              <p className="mt-2 text-sm text-muted-foreground">
                Try clearing a filter or browsing the full collection.
              </p>
              <button type="button" onClick={() => setParams({}, { replace: true })} className="btn-outline mt-8">
                Clear filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-x-3 gap-y-8 pt-6 sm:gap-x-4 sm:gap-y-10 lg:grid-cols-3">
              {visible.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}