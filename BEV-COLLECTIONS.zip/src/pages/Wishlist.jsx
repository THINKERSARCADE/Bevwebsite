const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

import { useCart } from '@/context/CartContext';
import ProductCard from '@/components/store/ProductCard';
import usePageMeta from '@/lib/usePageMeta';

const asArray = (result) => (Array.isArray(result) ? result : result?.items || []);

export default function Wishlist() {
  const { wishlist } = useCart();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  usePageMeta('Your Wishlist — Bev Collections', 'The pieces you have saved at Bev Collections.');

  useEffect(() => {
    db.entities.Product
      .filter({}, { limit: 200 })
      .then((page) => setProducts(asArray(page)))
      .catch(() => setProducts([]))
      .finally(() => setLoading(false));
  }, []);

  const saved = products.filter((product) => wishlist.includes(product.id));

  return (
    <div className="shell py-12 md:py-16">
      <p className="eyebrow">Saved pieces</p>
      <h1 className="mt-4 font-display text-4xl tracking-[-0.02em] md:text-5xl">Your Wishlist</h1>

      {loading ? (
        <div className="mt-12 grid gap-x-4 gap-y-10 sm:grid-cols-2 lg:grid-cols-4">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="aspect-[4/5] animate-pulse bg-secondary" />
          ))}
        </div>
      ) : saved.length === 0 ? (
        <div className="mt-10 max-w-md">
          <p className="text-sm leading-relaxed text-muted-foreground">
            Tap the heart on any piece to keep it here while you decide.
          </p>
          <Link to="/shop" className="btn-primary mt-8">
            Browse the collection
          </Link>
        </div>
      ) : (
        <div className="mt-12 grid gap-x-4 gap-y-10 sm:grid-cols-2 lg:grid-cols-4">
          {saved.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
}