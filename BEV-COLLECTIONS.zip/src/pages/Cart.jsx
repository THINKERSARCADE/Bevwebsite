const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

import { useCart } from '@/context/CartContext';
import { useStore } from '@/context/StoreContext';
import CartLine from '@/components/store/CartLine';
import { formatKES } from '@/lib/shop';
import { buildOrderSummary, whatsappLink } from '@/lib/orders';
import usePageMeta from '@/lib/usePageMeta';

const asArray = (result) => (Array.isArray(result) ? result : result?.items || []);

export default function Cart() {
  const { items, subtotal } = useCart();
  const { content } = useStore();
  const [products, setProducts] = useState([]);

  usePageMeta('Your Bag — Bev Collections', 'Review the pieces in your Bev Collections bag.');

  useEffect(() => {
    db.entities.Product
      .filter({}, { limit: 200 })
      .then((page) => setProducts(asArray(page)))
      .catch(() => setProducts([]));
  }, []);

  const findProduct = (id) => products.find((product) => product.id === id);

  const summary = {
    items,
    subtotal,
    delivery_fee: 0,
    discount: 0,
    total: subtotal,
    customer_name: '',
    phone: '',
    delivery_zone: '',
  };

  const message = buildOrderSummary(summary);

  return (
    <div className="shell py-12 md:py-16">
      <h1 className="font-display text-4xl tracking-[-0.02em] md:text-5xl">Your Bag</h1>
      <p className="mt-3 text-sm text-muted-foreground">
        {items.length === 0
          ? 'Your bag is empty for now.'
          : `${items.length} ${items.length === 1 ? 'piece' : 'pieces'} ready to go.`}
      </p>

      {items.length === 0 ? (
        <div className="mt-16 max-w-md">
          <p className="text-sm leading-relaxed text-muted-foreground">
            Browse the collection and add the pieces you love. We hold your bag on this device.
          </p>
          <Link to="/shop" className="btn-primary mt-8">
            Shop the collection
          </Link>
        </div>
      ) : (
        <div className="mt-10 grid gap-12 md:grid-cols-12">
          <div className="md:col-span-7">
            <div className="border-t border-border/70">
              {items.map((item) => {
                const product = findProduct(item.product_id);
                return (
                  <CartLine
                    key={item.key}
                    item={item}
                    sizes={product?.sizes || []}
                    colors={product?.colors || []}
                  />
                );
              })}
            </div>
            <Link
              to="/shop"
              className="mt-8 inline-block text-[10px] uppercase tracking-[0.24em] text-muted-foreground underline-offset-8 hover:text-foreground hover:underline"
            >
              Continue shopping
            </Link>
          </div>

          <aside className="md:col-span-5 md:pl-8">
            <div className="border border-border/70 bg-card p-6 md:p-8">
              <h2 className="eyebrow">Order summary</h2>
              <dl className="mt-6 space-y-3 text-sm">
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Subtotal</dt>
                  <dd>{formatKES(subtotal)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Delivery</dt>
                  <dd className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
                    Calculated at checkout
                  </dd>
                </div>
              </dl>
              <div className="mt-6 flex items-baseline justify-between border-t border-border/70 pt-5">
                <span className="text-[10px] uppercase tracking-[0.24em]">Total</span>
                <span className="font-display text-2xl">{formatKES(subtotal)}</span>
              </div>

              <Link to="/checkout" className="btn-primary mt-7 w-full">
                Proceed to checkout
              </Link>

              {content.whatsapp && (
                <a
                  href={whatsappLink(content.whatsapp, message)}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-3 flex items-center justify-center gap-2 border border-border px-6 py-4 text-[10px] uppercase tracking-[0.24em] transition-colors hover:border-foreground"
                >
                  Order on WhatsApp instead
                </a>
              )}

              <p className="mt-6 text-[10px] uppercase tracking-[0.18em] leading-relaxed text-muted-foreground">
                {content.payment_instructions}
              </p>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}