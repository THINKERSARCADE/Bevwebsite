import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '@/context/StoreContext';
import usePageMeta from '@/lib/usePageMeta';

export default function Track() {
  const navigate = useNavigate();
  const { content } = useStore();
  const [orderNumber, setOrderNumber] = useState('');
  const [phone, setPhone] = useState('');
  const [error, setError] = useState('');

  usePageMeta('Track your order — Bev Collections', 'Enter your order number and phone number to see delivery progress.');

  const submit = (event) => {
    event.preventDefault();
    const reference = orderNumber.trim().toUpperCase();
    if (!reference || !phone.trim()) {
      setError('Enter both your order number and phone number.');
      return;
    }
    navigate(`/order/${encodeURIComponent(reference)}?phone=${encodeURIComponent(phone.trim())}`);
  };

  return (
    <div className="shell max-w-xl py-16 md:py-24">
      <p className="eyebrow">Order tracking</p>
      <h1 className="mt-4 font-display text-4xl tracking-[-0.02em] md:text-5xl">
        Where is my order?
      </h1>
      <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
        Enter the order number from your confirmation together with the phone number you used.
      </p>

      <form onSubmit={submit} className="mt-10 space-y-4">
        <label className="block">
          <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
            Order number
          </span>
          <input
            value={orderNumber}
            onChange={(event) => {
              setOrderNumber(event.target.value);
              setError('');
            }}
            placeholder="BEV-XXXXXX"
            className="field mt-2"
          />
        </label>
        <label className="block">
          <span className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
            Phone number
          </span>
          <input
            value={phone}
            onChange={(event) => {
              setPhone(event.target.value);
              setError('');
            }}
            placeholder="07xx xxx xxx"
            inputMode="tel"
            className="field mt-2"
          />
        </label>
        {error && <p className="text-xs text-destructive">{error}</p>}
        <button type="submit" className="btn-primary w-full">
          Track order
        </button>
      </form>

      <p className="mt-8 text-xs leading-relaxed text-muted-foreground">{content.delivery_note}</p>
    </div>
  );
}