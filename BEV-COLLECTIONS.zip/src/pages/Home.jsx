const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

import Hero from '@/components/store/Hero';
import MobileSearchBar from '@/components/store/MobileSearchBar';
import StylePills from '@/components/store/StylePills';
import NewArrivalsGallery from '@/components/store/NewArrivalsGallery';
import CategoryGrid from '@/components/store/CategoryGrid';
import ProductRail from '@/components/store/ProductRail';
import CollectionsList from '@/components/store/CollectionsList';
import PromoBanner from '@/components/store/PromoBanner';
import Benefits from '@/components/store/Benefits';
import InstagramStrip from '@/components/store/InstagramStrip';
import Newsletter from '@/components/store/Newsletter';
import usePageMeta from '@/lib/usePageMeta';

const asArray = (result) => (Array.isArray(result) ? result : result?.items || []);

export default function Home() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  usePageMeta(
    'Bev Collections — Shoes, Clothing & Handbags in Kenya',
    'Shop shoes, clothing, handbags and accessories at Bev Collections. Carefully selected fashion, secure M-Pesa payments and reliable delivery across Kenya.'
  );

  useEffect(() => {
    let alive = true;
    db.entities.Product
      .filter({}, { sort: '-created_date', limit: 60 })
      .then((page) => {
        if (alive) setProducts(asArray(page).filter((product) => product.is_active !== false));
      })
      .catch(() => {})
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
  }, []);

  const latest = [...products]
    .sort((a, b) => {
      const fresh = Number(b.is_new_arrival || 0) - Number(a.is_new_arrival || 0);
      if (fresh !== 0) return fresh;
      return new Date(b.created_date) - new Date(a.created_date);
    })
    .slice(0, 5);

  const trending = products
    .filter((product) => product.is_featured || product.is_best_seller)
    .slice(0, 8);

  return (
    <>
      <Hero />

      <div className="pt-6">
        <MobileSearchBar />
      </div>

      <section className="mt-10 md:mt-14">
        <div className="shell flex items-end justify-between gap-4">
          <div>
            <p className="eyebrow">Just arrived</p>
            <h2 className="mt-2 font-display text-3xl leading-none tracking-[-0.02em] md:text-5xl">
              Newest
            </h2>
          </div>
          <Link
            to="/shop?filter=new"
            className="hidden text-[10px] uppercase tracking-[0.24em] text-muted-foreground underline-offset-8 hover:text-foreground hover:underline md:block"
          >
            View all
          </Link>
        </div>

        <div className="mt-5">
          <StylePills />
        </div>

        <NewArrivalsGallery products={latest} loading={loading} />
      </section>

      {loading ? (
        <div className="shell mt-16 grid gap-4 pb-16 sm:grid-cols-2 lg:grid-cols-4">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="aspect-[4/5] animate-pulse bg-secondary" />
          ))}
        </div>
      ) : (
        <ProductRail
          eyebrow="Trending now"
          title="Most wanted this week"
          description="The pieces our customers keep coming back for."
          products={trending}
          actionLabel="View all products"
          actionTo="/shop"
        />
      )}

      <CategoryGrid />
      <PromoBanner />
      <CollectionsList />
      <Benefits />
      <InstagramStrip />
      <Newsletter />
    </>
  );
}